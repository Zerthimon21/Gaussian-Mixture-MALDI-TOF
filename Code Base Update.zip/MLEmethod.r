rm(list = ls())
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml" 
setwd(FilePath)
source("IsotpoicFitLoad11.R") ##now includes library(xcms), AA

FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/HEKAT1TP0"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

SpectraImput <- xcmsRaw(FileList[1])
SpectraAverage <- getSpec(SpectraImput,mzrange=c(1294,1304))
plot(SpectraAverage[,1],SpectraAverage[,2],type='l')

PepMass=MassCalc('DRVYIHPFHL')
Sigma=.02
mzError=0
PD <- MultiNormCalc(SpectraPeptideRange[,1],'DRVYIHPFHL',PepMass,Sigma,mzError)