##Examination of new 2-10 1-9 mix data

rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad10.R") 

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngDil052413"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')

pdf(file = "Ang21019Data.pdf")
par(mfrow = c(3,1))
for(i in 1:length(FileList)){
		SpectraImput <- xcmsRaw(FileList[i])
		SpectraAverage <- getSpec(SpectraImput,mzrange=c(1180,1196))
		plot(SpectraAverage[,1],SpectraAverage[,2],type='l',xlab="MZ",ylab="Intensity",main=as.character(FileList[i]))
}
dev.off()


##############################

Sigma=seq(.001,.4,.001)
mzError=seq(-.4,.7,.001)

##Single Isotopic Cluster
PeptideInformation=PeptideInfo(UnlabeledPeptides[2:3],UnlabeledSequence[2:3],LabeledPeptides[2:3],LabeledSequence[2:3],AQUA=TRUE,Neutron=6,ClusterCut=5)
FRecord1=MultiPeakPeptideScan(FileList[19:27],PeptideInformation,Sigma,mzError)
range(FRecord1$mzError)

range(FRecord1$Sigma)


##Multiple Isotopic clusters
PeptideInformation=PeptideInfo(UnlabeledPeptides[2:3],UnlabeledSequence[2:3],LabeledPeptides[2:3],LabeledSequence[2:3],AQUA=TRUE,Neutron=6,ClusterCut=3)
FRecord2=MultiPeakPeptideScan(FileList[19:27],PeptideInformation,Sigma,mzError)
range(FRecord2$mzError)

range(FRecord2$Sigma)

PeptideInformation=PeptideInfo(UnlabeledPeptides[2:3],UnlabeledSequence[2:3],LabeledPeptides[2:3],LabeledSequence[2:3],AQUA=TRUE,Neutron=6,ClusterCut=5)
PeptideInformation=PeptideInformation[3:4,]
FRecord3=MultiPeakPeptideScan(FileList[1:18],PeptideInformation,Sigma,mzError)
range(FRecord3$mzError)

range(FRecord3$Sigma)

write.csv(FRecord1,'AngDil052413Data1.csv')
write.csv(FRecord2,'AngDil052413Data2.csv')
write.csv(FRecord3,'AngDil052413Data3.csv')

############################
##reload for analysis
############################
rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad10.R") 
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngDil052413"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')

FRecord1=read.csv('AngDil052413Data1.csv',stringsAsFactors=FALSE)
FRecord1=FRecord1[,-1]
FRecord2=read.csv('AngDil052413Data2.csv',stringsAsFactors=FALSE)
FRecord2=FRecord2[,-1]
FRecord3=read.csv('AngDil052413Data3.csv',stringsAsFactors=FALSE)
FRecord3=FRecord3[,-1]
FullRecord=rbind(FRecord1,FRecord2,FRecord3)

FileName="AngDil052413plot1.pdf"
ViewFitResults2(FRecord1,FileName,PageRow=3,PageCol=1)
FileName="AngDil052413plot2.pdf"
ViewFitResults2(FRecord2,FileName,PageRow=3,PageCol=1)
FileName="AngDil052413plot3.pdf"
ViewFitResults2(FRecord3,FileName,PageRow=3,PageCol=1)
############################################################
##2ns set of 1-9/2-10 mixes
rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad10.R") 

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang19210 053113"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')

Sigma=seq(.001,.4,.001)
mzError=seq(-.4,.7,.001)

##Single isotopic cluster
PeptideInformation=PeptideInfo(UnlabeledPeptides[2:3],UnlabeledSequence[2:3],LabeledPeptides[2:3],LabeledSequence[2:3],AQUA=TRUE,Neutron=6,ClusterCut=5)
FRecord1=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
range(FRecord1$mzError)
range(FRecord1$Sigma)

ge(FRecord1$mzError)
[1] -0.142  0.240
> range(FRecord1$Sigma)
[1] 0.051 0.240

##Multiple Isotopic clusters
PeptideInformation=PeptideInfo(UnlabeledPeptides[2:3],UnlabeledSequence[2:3],LabeledPeptides[2:3],LabeledSequence[2:3],AQUA=TRUE,Neutron=6,ClusterCut=3)
FRecord2=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
range(FRecord2$mzError)
range(FRecord2$Sigma)

> range(FRecord2$mzError)
[1] -0.161  0.242
> range(FRecord2$Sigma)
[1] 0.048 0.235

write.csv(FRecord1,'AngDil053113Data1.csv')
write.csv(FRecord2,'AngDil053113Data2.csv')
FileName="AngDil053113plot1.pdf"
ViewFitResults2(FRecord1,FileName,PageRow=3,PageCol=1)
FileName="AngDil053113plot2.pdf"
ViewFitResults2(FRecord2,FileName,PageRow=3,PageCol=1)

##Blank Analysis
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Blanks"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')

PeptideInformation=PeptideInfo(UnlabeledPeptides,UnlabeledSequence,LabeledPeptides,LabeledSequence,AQUA=TRUE,Neutron=6,ClusterCut=5)
FRecordBlanks=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
write.csv(FRecordBlanks,'AngDil053113Data1.csv')
range(FRecordBlanks$NoiseAdjust)
FileName="AngBlanksplot.pdf"
ViewFitResults2(FRecordBlanks,FileName,PageRow=3,PageCol=2)
############################################################
rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad10.R") 
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang19210 053113"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')

FRecord1=read.csv('AngDil053113Data1.csv',stringsAsFactors=FALSE)
FRecord1=FRecord1[,-1]
FRecord2=read.csv('AngDil053113Data2.csv',stringsAsFactors=FALSE)
FRecord2=FRecord2[,-1]
FullRecord=rbind(FRecord1,FRecord2)
length(FullRecord[,1])

ScoreVar=data.frame()
for(i in 1:72){
	ScoreVar[i,1]=as.character(FullRecord[(i*4),4]) 
	ScoreVar[i,2]=FullRecord[(i*4),9]/FullRecord[(i*4)-2,9]  
	ScoreVar[i,3]=FullRecord[((i*4)-1),9]/FullRecord[((i*4)-3),9]  
	ScoreVar[i,4]=FullRecord[(i*4),9]/FullRecord[(i*4)-1,9]  
	ScoreVar[i,5]=FullRecord[((i*4)-2),9]/FullRecord[((i*4)-3),9]  
	}

##2-10/AQUA
##1-9/AQUA
##2-10/1-9
##AQUA/AQUA
##NAME

Amnts=c(1000,1000,1000,1000,1000,1000,100,100,100,100,100,100,10,10,10,10,10,10,500,500,500,500,500,500,50,50,50,50,50,50,200,200,200,200,200,200,1000,1000,1000,1000,1000,1000,100,100,100,100,100,100,10,10,10,10,10,10,500,500,500,500,500,500,50,50,50,50,50,50,200,200,200,200,200,200)
Amnts2=c(1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000)
ScoreVar1=Amnts/100 ##Real 2-10/AQUA
ScoreVar2=Amnts/1000 ##Real 2-10/1-9
ScoreVar3=rep(4,72) ##Real 1-9/AQUA
ScoreVar4=rep(.4,72) ##Real AQUA/AQUA
ScoreVar=cbind(ScoreVar,ScoreVar1,ScoreVar2,ScoreVar3,ScoreVar4)
colnames(ScoreVar)=c('Names','Ang 2-10 est','Ang 1-9 est','Pep est','AQUA est','Real Ang 2-10 est','Real Ang 1-9 est','Real Pep est','Real AQUA est')
ScoreVar

#######################################################################
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Blanks"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')

FRecord=read.csv('AngDil053113Data1.csv',stringsAsFactors=FALSE)
FRecord=FRecord[,-1]

SpectraImput <- xcmsRaw(FileList[1])
SpectraAverage <- getSpec(SpectraImput,mzrange=c(650,1310))
Cluster=FRecord[1:15,]
BaselineEstimate=data.frame()
for(i in 1:length(Cluster[,1])){
SpectraPeptideRange <- SpectraAverage[SpectraAverage[,1]>=((Cluster$Mass[i]+Cluster$mzError[i])-1.008664916) & SpectraAverage[,1]<=((Cluster$Mass[i]+Cluster$mzError[i])+5*1.008664916),]
BaselineEstimate[i,1]=mean(SpectraPeptideRange[,2])
}
BaselineEstimate=cbind(BaselineEstimate,Cluster$NoiseAdjust)
BaselineEstimate

> BaselineEstimate
         V1 Cluster$NoiseAdjust
1  13.94256            13.96979
2  13.85123            13.74860
3  13.95197            13.95820
4  13.97421            13.95820
5  14.03471            13.95820
6  14.05627            13.95820
7  14.16381            14.19952
8  14.06222            14.05723
9  14.19077            14.09105
10 14.20201            14.14629
11 14.38223            14.35337
12 14.32569            14.39782
13 14.47921            14.51208
14 14.66164            14.67061
15 14.53195            14.56337