##Normalization by total ion current##
rm(list = ls())
library(xcms)
 
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions/Ang210"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList2 <- c(FileList[1:3],FileList[16:39],FileList[4:15])

MeanTICA=rep(0,length(FileList2))
for(i in 1:length(FileList2)){
SpectraImput <- xcmsRaw(FileList2[i])
MeanTICA[i]=(mean(SpectraImput@tic))
}

BaseDataA=read.csv("Ang210RoughData.csv",stringsAsFactors=FALSE)
BaseDataA=rbind(BaseDataA[1:3,],BaseDataA[16:39,],BaseDataA[4:15,])
NormArea= BaseDataA$Area/MeanTICA
fmolsDilution=c(10000,10000,10000,5000,5000,5000,1000,1000,1000,500,500,500,250,250,250,125,125,125,62.5,62.5,62.5,31.25,31.25,31.25,15.625,15.625,15.625,7.8125,7.8125,7.8125,3.90625,3.90625,3.90625,1.953125,1.953125,1.953125,0.9765625,0.9765625,0.9765625)

par(mfrow = c(1,3))
plot(fmolsDilution,NormArea,xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-2-10")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(NormArea,3,13)),col="red")
plot(fmolsDilution,NormArea,log="x",xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-2-10")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(NormArea,3,13)),col="red")
plot(fmolsDilution,NormArea,log="xy",xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-2-10")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(NormArea,3,13)),col="red")

#######################################
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions/Ang19"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList2 <- c(FileList[1:3],FileList[16:39],FileList[4:15])

MeanTICB=rep(0,length(FileList2))
for(i in 1:length(FileList2)){
SpectraImput <- xcmsRaw(FileList2[i])
MeanTICB[i]=(mean(SpectraImput@tic))
}
BaseDataA=read.csv("Ang19RoughData.csv",stringsAsFactors=FALSE)
BaseDataA=rbind(BaseDataA[1:3,],BaseDataA[16:39,],BaseDataA[4:15,])
NormArea= BaseDataA$Area/MeanTICB

par(mfrow = c(1,3))
plot(fmolsDilution,NormArea,xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-1-9")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(NormArea,3,13)),col="red")
plot(fmolsDilution,NormArea,log="x",xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-1-9")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(NormArea,3,13)),col="red")
plot(fmolsDilution,NormArea,log="xy",xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-1-9")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(NormArea,3,13)),col="red")
#######################################
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions062613/Ang210"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList2 <- c(FileList[1:3],FileList[16:39],FileList[4:15])

MeanTICC=rep(0,length(FileList2))

for(i in 1:length(FileList2)){
SpectraImput <- xcmsRaw(FileList2[i])
MeanTICC[i]=(mean(SpectraImput@tic))
}
BaseDataA=read.csv("Ang210RoughData.csv",stringsAsFactors=FALSE)
NormArea= abs(BaseDataA$Area/MeanTICC)

par(mfrow = c(1,3))
plot(fmolsDilution,NormArea,xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-2-10")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(NormArea,3,13)),col="red")
plot(fmolsDilution,NormArea,log="x",xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-2-10")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(NormArea,3,13)),col="red")
plot(fmolsDilution,NormArea,log="xy",xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-2-10")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(NormArea,3,13)),col="red")
#######################################
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions062613/Ang19"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList2 <- c(FileList[1:3],FileList[16:39],FileList[4:15])

MeanTICD=rep(0,length(FileList2))

for(i in 1:length(FileList2)){
SpectraImput <- xcmsRaw(FileList2[i])
MeanTICD[i]=(mean(SpectraImput@tic))
}
BaseDataA=read.csv("Ang19RoughData.csv",stringsAsFactors=FALSE)
NormArea= abs(BaseDataA$Area/MeanTICD)

par(mfrow = c(1,3))
plot(fmolsDilution,NormArea,xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-1-9")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(NormArea,3,13)),col="red")
plot(fmolsDilution,NormArea,log="x",xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-1-9")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(NormArea,3,13)),col="red")
plot(fmolsDilution,NormArea,log="xy",xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-1-9")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(NormArea,3,13)),col="red")

##########
##########
##########
##########
rm(list = ls())
library(xcms)
fmolsDilution=c(10000,10000,10000,5000,5000,5000,1000,1000,1000,500,500,500,250,250,250,125,125,125,62.5,62.5,62.5,31.25,31.25,31.25,15.625,15.625,15.625,7.8125,7.8125,7.8125,3.90625,3.90625,3.90625,1.953125,1.953125,1.953125,0.9765625,0.9765625,0.9765625)
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions/Ang210"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList2 <- c(FileList[1:3],FileList[16:39],FileList[4:15])

MeanTICA=rep(0,length(FileList2))
for(i in 1:length(FileList2)){
SpectraImput <- xcmsRaw(FileList2[i])
MeanTICA[i]=(mean(SpectraImput@tic))
}

BaseDataA=read.csv("Ang210RoughData.csv",stringsAsFactors=FALSE)
BaseDataA=rbind(BaseDataA[1:3,],BaseDataA[16:39,],BaseDataA[4:15,])
NormAreaA= BaseDataA$Area/MeanTICA
#######################################
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions/Ang19"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList2 <- c(FileList[1:3],FileList[16:39],FileList[4:15])

MeanTICB=rep(0,length(FileList2))
for(i in 1:length(FileList2)){
SpectraImput <- xcmsRaw(FileList2[i])
MeanTICB[i]=(mean(SpectraImput@tic))
}
BaseDataB=read.csv("Ang19RoughData.csv",stringsAsFactors=FALSE)
BaseDataB=rbind(BaseDataB[1:3,],BaseDataB[16:39,],BaseDataB[4:15,])
NormAreaB= BaseDataA$Area/MeanTICB
#######################################
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions062613/Ang210"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList2 <- c(FileList[1:3],FileList[16:39],FileList[4:15])

MeanTICC=rep(0,length(FileList2))

for(i in 1:length(FileList2)){
SpectraImput <- xcmsRaw(FileList2[i])
MeanTICC[i]=(mean(SpectraImput@tic))
}
BaseDataC=read.csv("Ang210RoughData.csv",stringsAsFactors=FALSE)
NormAreaC= abs(BaseDataA$Area/MeanTICC)
#######################################
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions062613/Ang19"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList2 <- c(FileList[1:3],FileList[16:39],FileList[4:15])

MeanTICD=rep(0,length(FileList2))

for(i in 1:length(FileList2)){
SpectraImput <- xcmsRaw(FileList2[i])
MeanTICD[i]=(mean(SpectraImput@tic))
}
BaseDataD=read.csv("Ang19RoughData.csv",stringsAsFactors=FALSE)
NormAreaD= abs(BaseDataA$Area/MeanTICD)
########################################
moles=c(fmolsDilution,fmolsDilution)
NormArea=c(NormAreaA,NormAreaC)
meanline1=colMeans(matrix(fmolsDilution,3,13))
meanline2=(colMeans(matrix(NormAreaA,3,13))+colMeans(matrix(NormAreaC,3,13)))/2

par(mfrow = c(1,3))
plot(moles,NormArea,xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-2-10")
lines(meanline1,meanline2,col="red")
plot(moles,NormArea,log="x",xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-2-10")
lines(meanline1,meanline2,col="red")
plot(moles,NormArea,log="xy",xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-2-10")
lines(meanline1,meanline2,col="red")

NormArea=c(NormAreaB,NormAreaD)
meanline2=(colMeans(matrix(NormAreaB,3,13))+colMeans(matrix(NormAreaD,3,13)))/2
par(mfrow = c(1,3))
plot(moles,NormArea,xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-1-9")
lines(meanline1,meanline2,col="red")
plot(moles,NormArea,log="x",xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-1-9")
lines(meanline1,meanline2,col="red")
plot(moles,NormArea,log="xy",xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-1-9")
lines(meanline1,meanline2,col="red")
#######################################################
##Color plots
meanline1=colMeans(matrix(fmolsDilution,3,13))
meanline2=(colMeans(matrix(NormAreaA,3,13))+colMeans(matrix(NormAreaC,3,13)))/2

plot(fmolsDilution,NormAreaA,log="xy",xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-2-10")
r3=c("blue","cyan","blue4")
coldic=rep(c(1,2,3),13)
for (i in 1:length(fmolsDilution)){
points(fmolsDilution[i],NormAreaA[i],col=r3[coldic[i]],pch = 19)
}

r3=c("red","orangered","red4")
for (i in 1:length(fmolsDilution)){
points(fmolsDilution[i]+.1*fmolsDilution[i],NormAreaC[i],col=r3[coldic[i]],pch = 19)
}
lines(meanline1,meanline2,col="red")
legend(1,1e-03,c("Trial1.Rep1","Trial1.Rep2","Trial1.Rep3","Trial2.Rep1","Trial2.Rep2","Trial2.Rep3"),col=c("blue","cyan","blue4","red","orangered","red4"),lty=c(1,1,1,1,1,1),pch = 19)
#######################################################
meanline1=colMeans(matrix(fmolsDilution,3,13))
meanline2=(colMeans(matrix(NormAreaB,3,13))+colMeans(matrix(NormAreaD,3,13)))/2

plot(fmolsDilution,NormAreaB,log="xy",xlab="fmols",ylab="Estimated Normalized Area",main="AQUA Ang-1-9")
r3=c("blue","cyan","blue4")
coldic=rep(c(1,2,3),13)
for (i in 1:length(fmolsDilution)){
points(fmolsDilution[i],NormAreaB[i],col=r3[coldic[i]],pch = 19)
}

r3=c("red","orangered","red4")
for (i in 1:length(fmolsDilution)){
points(fmolsDilution[i]+.1*fmolsDilution[i],NormAreaD[i],col=r3[coldic[i]],pch = 19)
}
lines(meanline1,meanline2,col="red")
legend(1,1e-03,c("Trial1.Rep1","Trial1.Rep2","Trial1.Rep3","Trial2.Rep1","Trial2.Rep2","Trial2.Rep3"),col=c("blue","cyan","blue4","red","orangered","red4"),lty=c(1,1,1,1,1,1),pch = 19)
#######################################################
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop"
setwd(FilePath0)
files=c(1.1,1.2,1.3,2.1,2.2,2.3,3.1,3.2,3.3,4.1,4.2,4.3,5.1,5.2,5.3,6.1,6.2,6.3,7.1,7.2,7.3,8.1,8.2,8.3,9.1,9.2,9.3,10.1,10.2,10.3,11.1,11.2,11.3,12.1,12.2,12.3,13.1,13.2,13.3)
TotalMeanTIC=cbind(files,MeanTICA,MeanTICB,MeanTICC,MeanTICD)
colnames(TotalMeanTIC)=c("Samples","2-10.1","1-9.1","2-10.2","1-9.2")
write.csv(TotalMeanTIC,"Spectra TIC.csv")

TotalNormData=cbind(fmolsDilution,NormAreaA,NormAreaB,NormAreaC,NormAreaD)
colnames(TotalNormData)=c("moles","2-10.1","1-9.1","2-10.2","1-9.2")
write.csv(TotalNormData,"Normalized Areas.csv")
######################################################################
##CV% plot
x=(matrix(NormAreaA,3,13))
cvx=rep(0,length(x[1,]))
for(i in 1:length(x[1,])){
cvx[i]=sd(x[,i])/mean(x[,i])
}
plot(meanline1,cvx*100,log="x",xlab="F.mols",ylab="CV%",main="CV% for normalized Area",type='l',col="red",xaxt="n")
axis(1,meanline1,meanline1,las=2)

x=(matrix(NormAreaB,3,13))
cvx=rep(0,length(x[1,]))
for(i in 1:length(x[1,])){
cvx[i]=sd(x[,i])/mean(x[,i])
}
lines(meanline1,cvx*100,type='l',col="blue")

x=(matrix(NormAreaC,3,13))
cvx=rep(0,length(x[1,]))
for(i in 1:length(x[1,])){
cvx[i]=sd(x[,i])/mean(x[,i])
}
lines(meanline1,cvx*100,type='l',col="black")

x=(matrix(NormAreaD,3,13))
cvx=rep(0,length(x[1,]))
for(i in 1:length(x[1,])){
cvx[i]=sd(x[,i])/mean(x[,i])
}
lines(meanline1,cvx*100,type='l',col="green")
legend(1,25,c("2-10.1","1-9.1","2-10.2","1-9.2"),col=c("red","blue","black","green"),lwd=c(1,1,1,1))


