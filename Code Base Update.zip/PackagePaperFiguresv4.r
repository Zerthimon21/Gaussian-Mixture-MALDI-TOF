rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad9.R") 

PeptideInformation = PeptideInformation[2,]  ##use ang1 

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngMixExperiments"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')

SpectraImput <- xcmsRaw(FileList[1])
SpectraAverage <- getSpec(SpectraImput,mzrange=c(500,1350))

Cluster <- PeptideInformation
PeptideInformation[PeptideInformation$Cluster==(1),]$Spectra <- FileList[1]
SpectraPeptideRange <- SpectraAverage[SpectraAverage[,1]>=(min(Cluster$Mass)-1.008664916) & SpectraAverage[,1]<=(max(Cluster$Mass)+5*1.008664916),]
plot(SpectraPeptideRange,type='l')

a <- seq(.04,.06,.001) ##sigma
b <- seq(.005,.025,.001) ##mzError
c <- expand.grid(a,b)
d <- rep(0,length(c[,1]))
storage <- cbind(c,d)

for (i in 1:length(storage[,1])){
	PredictedData <- rep(1,length(SpectraPeptideRange[,1]))
	PD <- MultiNormCalc(SpectraPeptideRange[,1],Cluster$Sequence,Cluster$Mass,vals[1],vals[2])
	PredictedData=cbind(PD[,2],PredictedData)
	Soln=qr.solve(PredictedData,SpectraPeptideRange[,2])
	yhat=PredictedData %*% Soln
	R=RsqCalc(SpectraPeptideRange,yhat)

	storage[i,3]=R
}
storage





Mass1=MassCalc("DRVYIHPFH")##1-9
Mass2=MassCalc("RVYIHPFHL")##2-10

	SpectraImput <- xcmsRaw(FileList[1])
	SpectraAverage <- getSpec(SpectraImput,mzrange=c(1170,1350))
	SpectraPeptideRange <- SpectraAverage[SpectraAverage[,1]>=(Mass2-1.008664916) & SpectraAverage[,1]<=(Mass1+5*1.008664916),]
	plot(SpectraPeptideRange[,1],SpectraPeptideRange[,2],type='l',xlab="MZ",ylab="Intensity",main="Figure 1: Fitting Overlapping Spectra")

	Curve1=MultiNormCalc(SpectraPeptideRange[,1],"DRVYIHPFH",Mass1,0.0524,0.0128)
	CurveA=Curve1[,2]*268.6089
	Curve2=MultiNormCalc(SpectraPeptideRange[,1],"RVYIHPFHL",Mass2,0.0524,0.0128)
	CurveB=Curve2[,2]*127.8486 
	TotalCurve=CurveA+CurveB+14.92728
	lines(SpectraPeptideRange[,1],TotalCurve ,col='red')
	
	legend(1187.25,1000,c("Mass Spectra","Estimated Peaks"), lty=c(1,1), col=c("black","red"))
