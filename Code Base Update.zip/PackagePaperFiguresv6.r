rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad10.R") 
######################################
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml/ExpandedParameters4"
######################################
PeptideInformation=PeptideInfo(UnlabeledPeptides[4],UnlabeledSequence[4],LabeledPeptides[4],LabeledSequence[4],AQUA=TRUE,Neutron=6,ClusterCut=5)
##Ang II (1uM) and AQUA (250nM)

Sigma=seq(.07,.36,.001)
mzError=seq(.02,.31,.001)

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/HEKAT1TP0"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
FRecord
setwd(FilePath0)
write.csv(FRecord,'HEKAT1TP0.csv')

#range(FRecord$mzError)
#0.029 0.309
#range(FRecord$Sigma)
#0.076 0.354
#range(FRecord$Rsq)
#0.8246179 0.9898703

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/HEKAT1TP0"
setwd(FilePath2)
ViewFitResults(FRecord,"New AngII data.pdf")

#############################################
##Must preprocess data from data scan
##load as seen below to allow strings
##remove left column, an artifact from the save to hd/load form hd cycle
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml/ExpandedParameters4"
setwd(FilePath0)
FRecord=read.csv('HEKAT1TP0.csv',stringsAsFactors=FALSE)
FRecord=FRecord[,-1]

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/HEKAT1TP0"
setwd(FilePath2)
ViewFitResults(FRecord,"New AngII data Again.pdf") 
PeakRecord=PeakAreaHeightScan(FRecord)

SpectraImput <- xcmsRaw("HEKAT1 1uM AngII + 100uM AMA TP0 R1 032113.mzXML")
SpectraAverage <- getSpec(SpectraImput,mzrange=c(1052,1058))	
plot(SpectraAverage[,1],SpectraAverage[,2],type='l')

Curve=MultiNormCalc(SpectraAverage[,1],FRecord[1,2],FRecord[1,3],FRecord[1,8],FRecord[1,7])
TotalCurve=(Curve[,2]*FRecord[1,9])+FRecord[1,10]
lines(SpectraAverage[,1],TotalCurve ,col='red')

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml/ExpandedParameters4"
setwd(FilePath0)
write.csv(PeakRecord,'HEKAT1TP0Sums.csv')
#########################################
##1uM AngII and 250 nM AQUA
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml/HEKAT1TP0"
setwd(FilePath0)
FRecord=read.csv('HEKAT1TP0.csv',stringsAsFactors=FALSE)
FRecord=FRecord[,-1]
Peakrecord=read.csv('HEKAT1TP0Sums.csv',stringsAsFactors=FALSE)
Peakrecord=Peakrecord[,-1]

ScoreVar=data.frame()
for(i in 1:9){
	ScoreVar[i,1]=FRecord[2*i,9]/FRecord[(2*i)-1,9]/4
	ScoreVar[i,2]=(Peakrecord[2*i,6]-(3*FRecord[2*i,10]))/(Peakrecord[(2*i)-1,6]-(3*FRecord[2*i-1,10]))/4
	ScoreVar[i,3]=Peakrecord[2*i,10]/Peakrecord[(2*i)-1,10]/4
}
colnames(ScoreVar)=c('RPeakQuant','Peak Sum','AUC Sum')
ScoreVar
write.csv(ScoreVar,'HEKAT1TP0AreaAnalysis.csv')

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml/HEKAT1TP0"
setwd(FilePath0)
ScoreVar=read.csv('HEKAT1TP0AreaAnalysis.csv',stringsAsFactors=FALSE)
ScoreVar=ScoreVar[,-1]

par(mfrow = c(1,3))
plot(ScoreVar[,1],ScoreVar[,2],xlab="RPeakQuant",ylab="Sum of Peak Intensities",ylim=c(.7,1), xlim=c(.7,1))
abline(0,1,col="red")
abline(h=.95,col="blue",lty=2)
abline(v=.95,col="blue",lty=2)
text(.75,.9,labels=expression(paste(rho,"= 0.954")))
title("Correlation of Peptide Amount \nPredicted by Percentage")
plot(ScoreVar[,1],ScoreVar[,3],xlab="RPeakQuant",ylab="Peak AUC",ylim=c(.7,1), xlim=c(.7,1))
abline(0,1,col="red")
abline(h=.95,col="blue",lty=2)
abline(v=.95,col="blue",lty=2)
text(.75,.9,labels=expression(paste(rho,"= 0.997")))
plot(ScoreVar[,3],ScoreVar[,2],xlab="Peak AUC",ylab="Sum of Peak Intensities",ylim=c(.7,1), xlim=c(.7,1))
abline(0,1,col="red")
abline(h=.95,col="blue",lty=2)
abline(v=.95,col="blue",lty=2)
text(.75,.9,labels=expression(paste(rho,"= 0.961")))

cor(ScoreVar[,1],ScoreVar[,2])
cor(ScoreVar[,1],ScoreVar[,3])
cor(ScoreVar[,2],ScoreVar[,3])

cov(ScoreVar[,1],ScoreVar[,2])
cov(ScoreVar[,1],ScoreVar[,3])
cov(ScoreVar[,2],ScoreVar[,3])

##Bias/mean/var
CompareVar=data.frame()
for(i in 1:length(ScoreVar[1,])){
	CompareVar[i,1]=mean((ScoreVar[,i]-1)^2)
	CompareVar[i,2]=var(ScoreVar[,i])
	CompareVar[i,3]=CompareVar[i,1]-CompareVar[i,2]
}
colnames(CompareVar)=c('MSE','Variance','Bias')
rownames(CompareVar)=c('RPeakQuant','Peak Sum','AUC Sum')
CompareVar
write.csv(CompareVar,'HEKAT1TP0MethodAnalysis.csv')

par(mfrow = c(1,3))
titlelist=c("RPeakQuant","Sum of Peak Intensities","Peak AUC")
for(i in 1:length(ScoreVar[1,])){
	boxplot(ScoreVar[,i],xlab=titlelist[i])
}

ScoreVar=read.csv('HEKAT1TP0AreaAnalysis.csv',stringsAsFactors=FALSE)
ScoreVar=ScoreVar[,-1]
boxplot(ScoreVar)