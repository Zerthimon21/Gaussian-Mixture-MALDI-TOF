rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad10.R") 

##Ang-1-9
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions062613/Ang19"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList2 <- c(FileList[1:3],FileList[16:39],FileList[4:15])

mzError=seq(-.5,.5,.001)
Sigma=seq(.001,.3,.001)
UnlabeledSequence = c("DRVYIHPFHL")
UnlabeledPeptides = c('AngI')
LabeledSequence = c("DRVYIHPFH")
LabeledPeptides = c('Ang-1-9')
PeptideInformation=PeptideInfo(UnlabeledPeptides,UnlabeledSequence,LabeledPeptides,LabeledSequence,AQUA=TRUE,Neutron=6,ClusterCut=5)
PeptideInformation=PeptideInformation[2,]
PeptideInformation[1,6]=1
FRecord1=MultiPeakPeptideScan(FileList2,PeptideInformation,Sigma,mzError,SpectraMin=801,SpectraMax=1250)
write.csv(FRecord1,'Ang19RoughData.csv')
FRecord1

FileName="Ang19plot.pdf"
ViewFitResults2(FRecord1,FileName,PageRow=3,PageCol=2)
Ang19Check=PeakAreaHeightScan(FRecord1)
write.csv(Ang19Check,'Ang19CheckData.csv')

##Ang2-10
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions062613/Ang210"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList2 <- c(FileList[1:3],FileList[16:39],FileList[4:15])

LabeledSequence = c("RVYIHPFHL")
LabeledPeptides = c('Ang-2-10')
PeptideInformation=PeptideInfo(UnlabeledPeptides,UnlabeledSequence,LabeledPeptides,LabeledSequence,AQUA=TRUE,Neutron=6,ClusterCut=5)
PeptideInformation=PeptideInformation[2,]
PeptideInformation[1,6]=1
FRecord2=MultiPeakPeptideScan(FileList2,PeptideInformation,Sigma,mzError,SpectraMin=801,SpectraMax=1250)
write.csv(FRecord2,'Ang210RoughData.csv')
FRecord2

FileName="Ang210plot.pdf"
ViewFitResults2(FRecord2,FileName,PageRow=3,PageCol=2)
Ang210Check=PeakAreaHeightScan(FRecord2)
write.csv(Ang210Check,'Ang210CheckData.csv')

fmolsDilution=c(10000,10000,10000,5000,5000,5000,1000,1000,1000,500,500,500,250,250,250,125,125,125,62.5,62.5,62.5,31.25,31.25,31.25,15.625,15.625,15.625,7.8125,7.8125,7.8125,3.90625,3.90625,3.90625,1.953125,1.953125,1.953125,0.9765625,0.9765625,0.9765625)
SummaryData1=cbind(FRecord2[,4],FRecord2[,9],Ang210Check[,6],fmolsDilution)
SummaryData2=cbind(FRecord1[,4],FRecord1[,9],Ang19Check[,6],fmolsDilution)

par(mfrow = c(2,3))
plot(SummaryData1[,4],SummaryData1[,2],xlab="fmols",ylab="Estimated Area Prediction",main="AQUA Ang-2-10 Area")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(as.numeric(SummaryData1[,2]),3,13)),col="red")
legend(1,800,"mean",col="red",lwd=1)
plot(SummaryData1[,4],SummaryData1[,2],log="x",xlab="log fmols",ylab="Estimated Area Prediction",main="AQUA Ang-2-10 Area")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(as.numeric(SummaryData1[,2]),3,13)),col="red")
legend(1,800,"mean",col="red",lwd=1)
plot(SummaryData1[,4],SummaryData1[,2],log="xy",xlab="log fmols",ylab="log Estimated Area Prediction",main="AQUA Ang-2-10 Area")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(as.numeric(SummaryData1[,2]),3,13)),col="red")
legend(1,800,"mean",col="red",lwd=1)

plot(SummaryData2[,4],SummaryData2[,2],xlab="fmols",ylab="Estimated Area Prediction",main="AQUA Ang-1-9 Area")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(as.numeric(SummaryData2[,2]),3,13)),col="red")
legend(1,500,"mean",col="red",lwd=1)
plot(SummaryData2[,4],SummaryData2[,2],log="x",xlab="log fmols",ylab="Estimated Area Prediction",main="AQUA Ang-1-9 Area")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(as.numeric(SummaryData2[,2]),3,13)),col="red")
legend(1,500,"mean",col="red",lwd=1)
plot(SummaryData2[,4],SummaryData2[,2],log="xy",xlab="log fmols",ylab="log Estimated Area Prediction",main="AQUA Ang-1-9 Area")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(as.numeric(SummaryData2[,2]),3,13)),col="red")
legend(1,800,"mean",col="red",lwd=1)

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions062613"
setwd(FilePath0)
TotalData=rbind(SummaryData1,SummaryData2)
colnames(TotalData)=c("File Title","Estimated Area","3 peak intensity sum","fmols per sample")
write.csv(TotalData,'DataSummary.csv')

##Ratio Analysis
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions062613"
setwd(FilePath0)
RatioData=read.csv("RatioDataSummary.csv")
fmolsDilution=c(10000,10000,10000,5000,5000,5000,1000,1000,1000,500,500,500,250,250,250,125,125,125,62.5,62.5,62.5,31.25,31.25,31.25,15.625,15.625,15.625,7.8125,7.8125,7.8125,3.90625,3.90625,3.90625,1.953125,1.953125,1.953125,0.9765625,0.9765625,0.9765625)

par(mfrow = c(1,3))
plot(fmolsDilution,RatioData[,3],xlab="fmols",ylab="Ang2-10/Ang1-9 Ratio",main="Ratio Analysis")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(as.numeric(RatioData[,3]),3,13)),col="red")
legend(1,15,"Mean",col="red",lwd=1)
plot(fmolsDilution,RatioData[,3],log="x",xlab="log fmols",ylab="Ang2-10/Ang1-9 Ratio",main="Ratio Analysis,x-log")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(as.numeric(RatioData[,3]),3,13)),col="red")
legend(1,15,"Mean",col="red",lwd=1)
plot(fmolsDilution,RatioData[,3],log="xy",xlab="log fmols",ylab="log Ang2-10/Ang1-9 Ratio",main="Ratio Analysis,xy-log")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(as.numeric(RatioData[,3]),3,13)),col="red")
legend(1,15,"Mean",col="red",lwd=1)

Ratio1=colMeans(matrix(as.numeric(RatioData[,1]/RatioData[,2]),3,13))
CV=c(0.2019677621,0.9268549784,0.7418561389,0.9500961515,0.1793345991,0.5032608992,0.8924723649,0.5730687709,0.32763987,0.5929864635,0.1478185659,1.1945930756,0.1380825489)
plot(colMeans(matrix(fmolsDilution,3,13)),CV,log="x",xlab="log fmols",ylab="CV%",main="CV% by fmols material")
lines(colMeans(matrix(fmolsDilution,3,13)),CV,col="red")