##For Spectra with single peptide clusters
ViewFitResults=function(SpectraFitRecord,FileTitle,PageRow=3,PageCol=2){
	pdf(file = FileTitle)
	par(mfrow = c(PageRow,PageCol))
	
	for(i in 1:length(SpectraFitRecord$SpectraCount)){
		SpectraImput <- xcmsRaw(as.character(SpectraFitRecord[i,4]))
		SpectraAverage <- getSpec(SpectraImput,mzrange=c(650,1350))
		SpectraPeptideRange <- SpectraAverage[SpectraAverage[,1]>=(min(SpectraFitRecord[i,3])-1.008664916) & SpectraAverage[,1]<=(max(SpectraFitRecord[i,3])+5*1.008664916),]
		plot(SpectraPeptideRange[,1],SpectraPeptideRange[,2],type='l',xlab="MZ",ylab="Intensity",main=paste(SpectraFitRecord[i,4],SpectraFitRecord[i,1]))
		PepLine=SpectraFitRecord[i,3]+SpectraFitRecord[i,7]
		abline(v=PepLine)
		ModelCurve=MultiNormCalc(SpectraPeptideRange[,1],SpectraFitRecord$Sequence[i],SpectraFitRecord$Mass[i],SpectraFitRecord$Sigma[i],SpectraFitRecord$mzError[i])
		Curve=(ModelCurve[,2]*SpectraFitRecord$Area[i])+SpectraFitRecord$NoiseAdjust[i]
		lines(SpectraPeptideRange[,1],Curve,col='red')
	}
	dev.off()
	cat("Please remember to shutdown R before opening any large .PDF, thank you.","\n")
}

##For Spectra with multiple peptide clusters
ViewFitResults2=function(SpectraFitRecord,FileTitle,PageRow=3,PageCol=2){
	pdf(file = FileTitle)
	par(mfrow = c(PageRow,PageCol))
	
	for(i in 1:max(SpectraFitRecord$SpectraCount)){
		Spectra <- SpectraFitRecord[SpectraFitRecord$SpectraCount==(i),]
		SpectraImput <- xcmsRaw(as.character(Spectra[1,4]))
		SpectraAverage <- getSpec(SpectraImput,mzrange=c(650,1350))
		for(j in 1:max(Spectra$Cluster)){
			Cluster <- Spectra[Spectra$Cluster==(j),]
			SpectraPeptideRange <- SpectraAverage[SpectraAverage[,1]>=(min(Cluster$Mass)-1.008664916) & SpectraAverage[,1]<=(max(Cluster$Mass)+5*1.008664916),]	
			plot(SpectraPeptideRange[,1],SpectraPeptideRange[,2],type='l',xlab="MZ",ylab="Intensity",main=paste(Cluster[j,4],SpectraFitRecord[j,1]))
			ModelPrediction <- rep(0,length(SpectraPeptideRange[,1]))
			for(k in 1:length(Cluster$Mass)){
				ModelCurve <- MultiNormClac(SpectraPeptideRange[,1],Cluster$Sequence[k],Cluster$Mass[k],Cluster$Sigma[k],Cluster$mzError[k])
				Curve <- (ModelCurve[,2]*Cluster$Area[k])
				ModelPrediction <- ModelPrediction+Curve
			}
			ModelPrediction <- ModelPrediction+Cluster$NoiseAdjust[1]
			lines(SpectraPeptideRange[,1],ModelPrediction,col='red')
		}

	}
	dev.off()
	cat("Please remember to shutdown R before opening any large .PDF, thank you.","\n")
}
##Peptide-Sequence-Mass-Spectra-SpectraCount-Cluster-mzError-Sigma-Area-NoiseAdjust-Rsq-ResidualMean-ResidualVariance
##Base on SpectralCount and Cluster numbers