rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad9.R") 

PeptideInformation <- PeptideInformation[2,]

Sigma <- seq(.04,.08,.001)
mzError <- seq(0,.05,.001)

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngMixExperiments"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList[1],PeptideInformation,Sigma,mzError)
FRecord

################
  Peptide   Sequence     Mass          Spectra SpectraCount Cluster mzError Sigma     Area NoiseAdjust       Rsq ResidualMean ResidualVariance
2    AngI DRVYIHPFHL 1296.685 ang mix 1a.mzXML            1       1   0.027 0.063 435.3356    17.92077 0.9790692 8.091646e-15         935.6047
###############


Mass=MassCalc("DRVYIHPFHL")

	SpectraImput <- xcmsRaw(FileList[1])
	SpectraAverage <- getSpec(SpectraImput,mzrange=c(1170,1350))
	SpectraPeptideRange <- SpectraAverage[SpectraAverage[,1]>=(Mass-1.008664916) & SpectraAverage[,1]<=(Mass+5*1.008664916),]
	plot(SpectraPeptideRange[,1],SpectraPeptideRange[,2],type='l',xlab="MZ",ylab="Intensity")

	Curve1=MultiNormCalc(SpectraPeptideRange[,1],"DRVYIHPFHL",Mass,0.063,0.027)
	CurveA=Curve1[,2]*435.3356

	TotalCurve=CurveA+17.92077
	lines(SpectraPeptideRange[,1],TotalCurve ,col='red')
	
	legend(1187.25,1000,c("Mass Spectra","Estimated Peaks"), lty=c(1,1), col=c("black","red"))


####################
####################

rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad9.R") 

PeptideInformation = PeptideInformation[2,]  ##use ang1 

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngMixExperiments"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')

SpectraImput <- xcmsRaw(FileList[1])
SpectraAverage <- getSpec(SpectraImput,mzrange=c(500,1350))

Cluster <- PeptideInformation
PeptideInformation[PeptideInformation$Cluster==(1),]$Spectra <- FileList[1]
SpectraPeptideRange <- SpectraAverage[SpectraAverage[,1]>=(min(Cluster$Mass)-1.008664916) & SpectraAverage[,1]<=(max(Cluster$Mass)+5*1.008664916),]
##plot(SpectraPeptideRange,type='l')

a <- seq(.01,.5,.01) ##sigma
b <- seq(-2.5,2.5,.01) ##mzError
c <- expand.grid(a,b)
d <- rep(0,length(c[,1]))
storage <- cbind(c,d)

for (i in 1:length(storage[,1])){
	PredictedData <- rep(1,length(SpectraPeptideRange[,1]))
	PD <- MultiNormCalc(SpectraPeptideRange[,1],Cluster$Sequence,Cluster$Mass,storage[i,1],storage[i,2])
	PredictedData=cbind(PD[,2],PredictedData)
	Soln=qr.solve(PredictedData,SpectraPeptideRange[,2])
	yhat=PredictedData %*% Soln
	R=RsqCalc(SpectraPeptideRange,yhat)

	storage[i,3]=R
}
library(scatterplot3d)
scatterplot3d(storage[,1], storage[,2], storage[,3], xlab="sigma", ylab="mzError", zlab="R Squared", main="ang mix 1a.mzXML Ang I fit", angle=40, type="l")

library(rgl)

plot3d(storage[,1], storage[,2], storage[,3], col="red", type="h", size=3, xlab="sigma", ylab="mzError", zlab="R Squared") 
