##Test differnt MultiNormCalc fns
rm(list=ls())
ls()
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad6.R") 
FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/rproftest"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
Sigma=seq(.05,.25,.01)
mzError=seq(-.4,.38,.01)

Rprof('AlgTimingNewProg.out')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
Rprof(append=TRUE)
EditedResults=QuickEditResults(FRecord,.7)##Removes anything with Rsq<cutoff
write.csv(FRecord,'SampleNewAlg.csv')
write.csv(EditedResults,'SampleNewAlgEdits.csv')

##Looking at Ol Alg
MultiNormCalc=function(SpectraRange,peptide,mass,sigma,mzError=0){

	Mass=mass
	h=IsotopicCountFFT(peptide)
	mz=SpectraRange
	norm=rep(0,length(mz))
	for(i in 1:length(h)){
		norm=norm+dnorm(mz-Mass,((i-1)*1.008664916)+mzError,sigma)*h[i]
	}
	norm=norm/max(norm)
	Predicted=matrix(0,length(mz),2)
	Predicted[,1]=mz
	Predicted[,2]=norm
	Predicted
}

Rprof('AlgTimingOldProg.out')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
Rprof(append=TRUE)
EditedResults=QuickEditResults(FRecord,.7)##Removes anything with Rsq<cutoff
write.csv(FRecord,'SampleOldAlg.csv')
write.csv(EditedResults,'SampleOldAlgEdits.csv')

SummaryA=summaryRprof('AlgTimingOldProg.out')
SummaryB=summaryRprof('AlgTimingNewProg.out')

SummaryA$sampling.time
SummaryB$sampling.time

SummaryA$by.total[1:5,]
SummaryB$by.total[1:5,]
