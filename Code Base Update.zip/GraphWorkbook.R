rm(list=ls())
ls()
library(xcms)
##Load functions file
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad6.R") 
##Change file path to set of files to be scanned
FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/mPod P28 1h run"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FileList
length(FileList)
ls()

PeptideInformation=PepInfo(AngPeptides,AQUAPeptides,AQUA=TRUE,Neutron=6)

SpectraImput <- xcmsRaw(FileList[1])
SpectraAverage <- getSpec(SpectraImput,mzrange=c(500,1350))

Cluster <- PeptideInformation[PeptideInformation$Cluster==(3),]
SpectraPeptideRange <- SpectraAverage[SpectraAverage[,1]>=(min(Cluster$Mass)-1.008664916) & SpectraAverage[,1]<=(max(Cluster$Mass)+5*1.008664916),]	

Sigma1=seq(.05,.2,.01)
mzError1=seq(-.5,.5,.01)
combine1=expand.grid(Sigma1,mzError1)
length(combine1$Var1)
RList1=rep(0,length(combine1$Var1))
for (i in 1:length(combine1$Var1)){
	PredictedData <- rep(1,length(SpectraPeptideRange[,1]))
	for(j in 1:length(Cluster$Mass)){
		PD <- MultiNormCalc(SpectraPeptideRange[,1],Cluster$Sequence[j],Cluster$Mass[j],combine1$Var1[i],combine1$Var2[i])
		PredictedData=cbind(PD[,2],PredictedData)
	}
	Soln=qr.solve(PredictedData,SpectraPeptideRange[,2])
	yhat=PredictedData %*% Soln
	RList1[i]=RsqCalc(SpectraPeptideRange,yhat)
}
combine3=cbind(combine1,RList1)

Rsq=matrix(RList1,length(Sigma1),length(mzError1))
max(RList)

par(mfrow=c(2,1))
persp(Sigma1, mzError1, Rsq, theta = 0, phi = 0, col = "lightblue")
persp(Sigma1, mzError1, Rsq, theta = 45, phi = 45, expand = 1, col = "lightblue")
#############################################################################
Sigma2=seq(.05,.15,.025)
mzError2=seq(-.5,.5,.025)

combine1=expand.grid(Sigma2,mzError2)