rm(list = ls())
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml" 
setwd(FilePath)
source("IsotpoicFitLoad11.R") ##now includes library(xcms), AA

#FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/SpectraSim" ##create folder 
#setwd(FilePath)

SpectraSimulationParameters=as.data.frame(matrix(0, ncol = 8, nrow = 1))
colnames(SpectraSimulationParameters)=c('Name','Peptide','PeptideMass','Clusters','mzError','Sigma','BaselineNoise','PeakAreas')

PeptideMin=7
PeptideMax=10
SimNumber=10
PeakArea=c(1500,1000,750,500,250,100)

#Peptide=NA
#PeptideMass=NA

for(z in 1:SimNumber){
x = ceiling(runif(1,PeptideMin-1,PeptideMax))
pep=rep(0,x)
for (i in 1:x){
	pep[i] = AA[ceiling(runif(1,0,20))]
}
peptype=runif(1,0,1)
if(peptype>=.9){Cluster = 4} 
else if(peptype>=.8){Cluster = 2}
else if(peptype>=.7){Cluster = 2.5} ##strange peak offset, mimic 2nd compund
else {Cluster = 1}
SpectraSimulationParameters[z,1] = paste("FakePeptide",z)
SpectraSimulationParameters[z,2] = paste(pep,collapse = "")
SpectraSimulationParameters[z,3] = MassCalc(SpectraSimulationParameters[z,2])
SpectraSimulationParameters[z,4] = Cluster
SpectraSimulationParameters[z,5] = round(runif(1,-.4,.4),digits = 2)
SpectraSimulationParameters[z,6] = round(runif(1,.01,.3),digits = 2)
SpectraSimulationParameters[z,8] = PeakArea[ceiling(runif(1,min=0,max=length(PeakArea)))]
SpectraSimulationParameters[z,7] = round(runif(1,9,55),digits = 2)+ (SpectraSimulationParameters[z,8]/100)
}
SpectraSimulationParameters
##write.csv(SpectraSimulationParameters,"SpectraSimulationParameters.csv")

###########################################################################
###########################################################################

MZDense=50
##Number of Neutrons around target mass
NBack=3
Nforward=7
SpectraSimulations=as.data.frame(matrix(0, ncol = 1, nrow = ceiling((NBack+Nforward)*1.008664916*MZDense)))
##Noise Addition
rho=.9
UnifRange=2
Base=10
##Slice of simulated spectra that covers noise
SDback=2.5
#Peaks=3		##N+Peaks of spectra to be shown
for(i in 1:length(SpectraSimulationParameters[,1])){
	PepRange = seq(SpectraSimulationParameters[i,3]-NBack*1.008664916,SpectraSimulationParameters[i,3]+Nforward*1.008664916,1/MZDense)##~50 data points per Neutron mass

	BaseNoise=rep(Base,(length(PepRange)+200))
	for(l in 1:(length(BaseNoise))){
		BaseNoise[l+1]=rho*BaseNoise[l]+runif(1,0,UnifRange)
	}
	NoiseAddition=(BaseNoise[101:(length(PepRange)+100)]) - mean(BaseNoise[101:(length(PepRange)+100)])+SpectraSimulationParameters[i,7]

	PeakSample=MultiNormCalc(PepRange,SpectraSimulationParameters[i,2],SpectraSimulationParameters[i,3],SpectraSimulationParameters[i,6],SpectraSimulationParameters[i,5])
	PeakSample[,2]=(PeakSample[,2]*SpectraSimulationParameters[i,8])+SpectraSimulationParameters[i,7] 

#	CleanPeak=PeakSample[,2]
	Peaks=length(IsotopicCountFFT(SpectraSimulationParameters[i,2],cutoff=.9))-1 ##Subtacts main peak 

	for(m in 1:length(PepRange)){
		if(PeakSample[m,1]<(SpectraSimulationParameters[i,3]+SpectraSimulationParameters[i,5]-SDback*SpectraSimulationParameters[i,6]))
			PeakSample[m,2]=NoiseAddition[m]

		if(PeakSample[m,1]>(SpectraSimulationParameters[i,3]+SpectraSimulationParameters[i,5]+SDback*SpectraSimulationParameters[i,6]+Peaks*1.008664916))
			PeakSample[m,2]=PeakSample[m,2] + NoiseAddition[m] - SpectraSimulationParameters[i,7] 
	}
	
	##Adding noise between peaks
		if(2*SDback*SpectraSimulationParameters[i,6]<1.008664916){
	
			TimedNoise=cbind(PepRange,NoiseAddition)
	
			for(y in 1:Peaks){
				ValleyCutOff1=(SpectraSimulationParameters[i,3]+SpectraSimulationParameters[i,5]+(y-1)*1.008664916+SDback*SpectraSimulationParameters[i,6])
				ValleyCutOff2=(SpectraSimulationParameters[i,3]+SpectraSimulationParameters[i,5]+(y)*1.008664916-SDback*SpectraSimulationParameters[i,6])

				PeakSample[PeakSample[,1]>=ValleyCutOff1 & PeakSample[,1]<=ValleyCutOff2,2]=TimedNoise[TimedNoise[,1]>=ValleyCutOff1 & TimedNoise[,1]<=ValleyCutOff2,2]				
			}
		}
	colnames(PeakSample)=c('MZ','Intensity')
	##FileTitle=paste(SpectraSimulationParameters[i,1],'Spectra.csv',collapse = "")
	##write.csv(PeakSample,FileTitle)
	SpectraSimulations=cbind(SpectraSimulations,PeakSample)
}
SpectraSimulations=SpectraSimulations[,-1]
##write.csv(SpectraSimulations,"SpectraSimulations.csv")

###########################################################################
###########################################################################
par(mfrow=c(,))

SpectraSimulations[1:5,]
abline(h=SpectraSimulationParameters[5,7])
plot(SpectraSimulations[,1],SpectraSimulations[,2],type='l')

PepRange = seq(SpectraSimulationParameters[1,3]-3*1.008664916,SpectraSimulationParameters[1,3]+7*1.008664916,.02)##~50 data points per Neutron mass
PeakSample=MultiNormCalc(PepRange,SpectraSimulationParameters[1,2],SpectraSimulationParameters[1,3],SpectraSimulationParameters[1,6],SpectraSimulationParameters[1,5])
PeakSample[,2]=(PeakSample[,2]*SpectraSimulationParameters[1,8])+SpectraSimulationParameters[1,7]
plot(PeakSample[,9],PeakSample[,10],type='l',col='red')

##Try adding to the final peaks.....baseline needs to be adjusted by area/ signal strength... After 3/4 the peak just add noise....

FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/HEKAT1TP0"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')
UnlabeledSequence = c('DRVYIHPF',"RVYIHPFHL")
UnlabeledPeptides = c('AngII','Ang-2-10')
LabeledSequence = c('DRVYIHPF',"RVYIHPFHL")
LabeledPeptides = c('AngII','Ang-2-10')
PeptideInformation=PeptideInfo2(UnlabeledPeptides,UnlabeledSequence,LabeledPeptides,LabeledSequence,Neutron=6,ClusterCut=5)
Sigma=seq(.01,.3,.01)
mzError=seq(-.7,.7,.01)
FRecord=MultiPeakPeptideScan2(FileList,PeptideInformation,Sigma,mzError)

SpectraImput <- xcmsRaw(FileList[6])
SpectraAverage <- getSpec(SpectraImput,mzrange=c(1045,1052))
plot(SpectraAverage[,1],SpectraAverage[,2],type='l')
abline(h=40.3)

###########################################################################
###########################################################################
##2nd arima fitting
rm(list = ls())
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml" 
setwd(FilePath)
source("IsotpoicFitLoad11.R") ##now includes library(xcms), AA

FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/HEKAT1TP0"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

PrePeakAnalysis1=rep(0,length(FileList))
x=1046
PostPeakAnalysis1=rep(0,length(FileList))
y=1052+4
for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	PrePeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(x-5,x))
	PostPeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(y,y+5))
	xyz1=arima(PrePeakSpectraAverage[,2],order=c(1,0,0))
	xyz2=arima(PostPeakSpectraAverage[,2],order=c(1,0,0))
	PrePeakAnalysis1[i]=as.numeric(as.character(coef(xyz1)[1]))
	PostPeakAnalysis1[i]=as.numeric(as.character(coef(xyz2)[1]))
}
##
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang210Ang19 071013"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

PrePeakAnalysis2=rep(0,length(FileList))
x=1181
PostPeakAnalysis2=rep(0,length(FileList))
y=1189+4
for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	PrePeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(x-5,x))
	PostPeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(y,y+5))
	xyz1=arima(PrePeakSpectraAverage[,2],order=c(1,0,0))
	xyz2=arima(PostPeakSpectraAverage[,2],order=c(1,0,0))
	PrePeakAnalysis2[i]=as.numeric(as.character(coef(xyz1)[1]))
	PostPeakAnalysis2[i]=as.numeric(as.character(coef(xyz2)[1]))
}
##
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang210Ang19 071113/Full"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

PrePeakAnalysis3=rep(0,length(FileList))
x=1181
PostPeakAnalysis3=rep(0,length(FileList))
y=1189+4
for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	PrePeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(x-5,x))
	PostPeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(y,y+5))
	xyz1=arima(PrePeakSpectraAverage[,2],order=c(1,0,0))
	xyz2=arima(PostPeakSpectraAverage[,2],order=c(1,0,0))
	PrePeakAnalysis3[i]=as.numeric(as.character(coef(xyz1)[1]))
	PostPeakAnalysis3[i]=as.numeric(as.character(coef(xyz2)[1]))
}
##
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang210Serial"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

PrePeakAnalysis4=rep(0,length(FileList))
x=1186
PostPeakAnalysis4=rep(0,length(FileList))
y=1191
for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	PrePeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(x-5,x))
	PostPeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(y,y+5))
	xyz1=arima(PrePeakSpectraAverage[,2],order=c(1,0,0))
	xyz2=arima(PostPeakSpectraAverage[,2],order=c(1,0,0))
	PrePeakAnalysis4[i]=as.numeric(as.character(coef(xyz1)[1]))
	PostPeakAnalysis4[i]=as.numeric(as.character(coef(xyz2)[1]))
}
##
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang19210 053113"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

PrePeakAnalysis5=rep(0,length(FileList))
x=1180
PostPeakAnalysis5=rep(0,length(FileList))
y=1193
for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	PrePeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(x-5,x))
	PostPeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(y,y+5))
	xyz1=arima(PrePeakSpectraAverage[,2],order=c(1,0,0))
	xyz2=arima(PostPeakSpectraAverage[,2],order=c(1,0,0))
	PrePeakAnalysis5[i]=as.numeric(as.character(coef(xyz1)[1]))
	PostPeakAnalysis5[i]=as.numeric(as.character(coef(xyz2)[1]))
}
##
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngDil052413"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

PrePeakAnalysis6=rep(0,length(FileList))
x=1180
PostPeakAnalysis6=rep(0,length(FileList))
y=1193
for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	PrePeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(x-5,x))
	PostPeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(y,y+5))
	xyz1=arima(PrePeakSpectraAverage[,2],order=c(1,0,0))
	xyz2=arima(PostPeakSpectraAverage[,2],order=c(1,0,0))
	PrePeakAnalysis6[i]=as.numeric(as.character(coef(xyz1)[1]))
	PostPeakAnalysis6[i]=as.numeric(as.character(coef(xyz2)[1]))
}
##
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngMixExperiments"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

PrePeakAnalysis7=rep(0,length(FileList))
x=1180
PostPeakAnalysis7=rep(0,length(FileList))
y=1188
for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	PrePeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(x-5,x))
	PostPeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(y,y+5))
	xyz1=arima(PrePeakSpectraAverage[,2],order=c(1,0,0))
	xyz2=arima(PostPeakSpectraAverage[,2],order=c(1,0,0))
	PrePeakAnalysis7[i]=as.numeric(as.character(coef(xyz1)[1]))
	PostPeakAnalysis7[i]=as.numeric(as.character(coef(xyz2)[1]))
}
##
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions/Ang19"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

PrePeakAnalysis8=rep(0,length(FileList))
x=1189
PostPeakAnalysis8=rep(0,length(FileList))
y=1194
for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	PrePeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(x-5,x))
	PostPeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(y,y+5))
	xyz1=arima(PrePeakSpectraAverage[,2],order=c(1,0,0))
	xyz2=arima(PostPeakSpectraAverage[,2],order=c(1,0,0))
	PrePeakAnalysis8[i]=as.numeric(as.character(coef(xyz1)[1]))
	PostPeakAnalysis8[i]=as.numeric(as.character(coef(xyz2)[1]))
}
##
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions/Ang210"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

PrePeakAnalysis9=rep(0,length(FileList))
x=1186
PostPeakAnalysis9=rep(0,length(FileList))
y=1191
for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	PrePeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(x-5,x))
	PostPeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(y,y+5))
	xyz1=arima(PrePeakSpectraAverage[,2],order=c(1,0,0),method="ML")
	xyz2=arima(PostPeakSpectraAverage[,2],order=c(1,0,0),method="ML")
	PrePeakAnalysis9[i]=as.numeric(as.character(coef(xyz1)[1]))
	PostPeakAnalysis9[i]=as.numeric(as.character(coef(xyz2)[1]))
}
##
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions062613/Ang19"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

PrePeakAnalysis10=rep(0,length(FileList))
x=1188
PostPeakAnalysis10=rep(0,length(FileList))
y=1194
for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	PrePeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(x-5,x))
	PostPeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(y,y+5))
	xyz1=arima(PrePeakSpectraAverage[,2],order=c(1,0,0))
	xyz2=arima(PostPeakSpectraAverage[,2],order=c(1,0,0))
	PrePeakAnalysis10[i]=as.numeric(as.character(coef(xyz1)[1]))
	PostPeakAnalysis10[i]=as.numeric(as.character(coef(xyz2)[1]))
}
##
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions062613/Ang210"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

PrePeakAnalysis11=rep(0,length(FileList))
x=1186
PostPeakAnalysis11=rep(0,length(FileList))
y=1194
for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	PrePeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(x-5,x))
	PostPeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(y,y+5))
	xyz1=arima(PrePeakSpectraAverage[,2],order=c(1,0,0),method="ML")
	xyz2=arima(PostPeakSpectraAverage[,2],order=c(1,0,0),method="ML")
	PrePeakAnalysis11[i]=as.numeric(as.character(coef(xyz1)[1]))
	PostPeakAnalysis11[i]=as.numeric(as.character(coef(xyz2)[1]))
}
##
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Blanks"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

PrePeakAnalysis12=rep(0,length(FileList))
x=1188
PostPeakAnalysis12=rep(0,length(FileList))
y=1194
for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	PrePeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(x-5,x))
	PostPeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(y,y+5))
	xyz1=arima(PrePeakSpectraAverage[,2],order=c(1,0,0))
	xyz2=arima(PostPeakSpectraAverage[,2],order=c(1,0,0))
	PrePeakAnalysis12[i]=as.numeric(as.character(coef(xyz1)[1]))
	PostPeakAnalysis12[i]=as.numeric(as.character(coef(xyz2)[1]))
}
##
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/CocktailStock"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

PrePeakAnalysis13=rep(0,length(FileList))
x=1050
PostPeakAnalysis13=rep(0,length(FileList))
y=1056
for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	PrePeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(x-5,x))
	PostPeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(y,y+5))
	xyz1=arima(PrePeakSpectraAverage[,2],order=c(1,0,0))
	xyz2=arima(PostPeakSpectraAverage[,2],order=c(1,0,0))
	PrePeakAnalysis13[i]=as.numeric(as.character(coef(xyz1)[1]))
	PostPeakAnalysis13[i]=as.numeric(as.character(coef(xyz2)[1]))
}
##
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/PlateTest"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

PrePeakAnalysis14=rep(0,length(FileList))
x=1186
PostPeakAnalysis14=rep(0,length(FileList))
y=1192
for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	PrePeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(x-5,x))
	PostPeakSpectraAverage <- getSpec(SpectraImput,mzrange=c(y,y+5))
	xyz1=arima(PrePeakSpectraAverage[,2],order=c(1,0,0))
	xyz2=arima(PostPeakSpectraAverage[,2],order=c(1,0,0))
	PrePeakAnalysis14[i]=as.numeric(as.character(coef(xyz1)[1]))
	PostPeakAnalysis14[i]=as.numeric(as.character(coef(xyz2)[1]))
}
##
PrePeakAnalysis1
PostPeakAnalysis1
PrePeakAnalysis2
PostPeakAnalysis2
PrePeakAnalysis3
PostPeakAnalysis3
PrePeakAnalysis4
PostPeakAnalysis4
PrePeakAnalysis5
PostPeakAnalysis5
PrePeakAnalysis6
PostPeakAnalysis6
PrePeakAnalysis7
PostPeakAnalysis7
PrePeakAnalysis8
PostPeakAnalysis8
PrePeakAnalysis9
PostPeakAnalysis9
PrePeakAnalysis10
PostPeakAnalysis10
PrePeakAnalysis11
PostPeakAnalysis11
PrePeakAnalysis12
PostPeakAnalysis12
PrePeakAnalysis13
PostPeakAnalysis13
PrePeakAnalysis14
PostPeakAnalysis14

prepeaks=c(PrePeakAnalysis1,PrePeakAnalysis2,PrePeakAnalysis3,PrePeakAnalysis4,PrePeakAnalysis5,PrePeakAnalysis6,PrePeakAnalysis7,PrePeakAnalysis8,PrePeakAnalysis9,PrePeakAnalysis10,PrePeakAnalysis11,PrePeakAnalysis12,PrePeakAnalysis13,PrePeakAnalysis14)
mean(prepeaks)
postpeaks=c(PostPeakAnalysis1,PostPeakAnalysis2,PostPeakAnalysis3,PostPeakAnalysis4,PostPeakAnalysis5,PostPeakAnalysis6,PostPeakAnalysis7,PostPeakAnalysis8,PostPeakAnalysis9,PostPeakAnalysis10,PostPeakAnalysis11,PostPeakAnalysis12,PostPeakAnalysis13,PostPeakAnalysis14)
mean(postpeaks)
peakinfo=c(prepeaks,postpeaks)
vec=seq(-1,1,.1)
vec=seq(-1,1,.01)
hist(peakinfo,vec)
##
rm(list = ls())

FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Reads"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*csv')

mzError=NA
Sigma=NA
Area =NA
NoiseAdjustBaseline=NA
Rsq=NA

mzErrorFull=NA
SigmaFull=NA
AreaFull=NA
NoiseAdjustBaselineFull=NA
RsqFull=NA

for (i in 1:length(FileList)){
	x=read.csv(FileList[i])
print(FileList[i])
	par1=unique(x[,8])
	que1=x[,8]
#print('mzError')
	par2=unique(x[,9])
	que2=x[,9]
#print('Sigma')
	par3=unique(x[,10])
	que3=x[,10]
#print('Area')
	par4=unique(x[,11])
	que4=x[,11]
#print('NoiseAdjustBaseline')
	par5=unique(x[,12])
	que5=x[,12]
#print('Rsq')
	 
	mzError=c(mzError,par1)
	Sigma=c(Sigma,par2)
	Area=c(Area,par3)
	NoiseAdjustBaseline=c(NoiseAdjustBaseline,par4)
	Rsq=c(Rsq,par5)
	
	mzErrorFull=c(mzErrorFull,que1)
	SigmaFull=c(SigmaFull,que2)
	AreaFull=c(AreaFull,que3)
	NoiseAdjustBaselineFull=c(NoiseAdjustBaselineFull,que4)
	RsqFull=c(RsqFull,que5)
}
mzError=mzError[-1]
Sigma=Sigma[-1]
Area =Area[-1]
NoiseAdjustBaseline=NoiseAdjustBaseline[-1]
Rsq=Rsq[-1]

mzErrorFull=mzErrorFull[-1]
SigmaFull=SigmaFull[-1]
AreaFull=AreaFull[-1]
NoiseAdjustBaselineFull=NoiseAdjustBaselineFull[-1]
RsqFull=RsqFull[-1]

range(mzError)
range(Sigma)
range(Area)
range(NoiseAdjustBaseline)
range(Rsq)

range(mzErrorFull)
range(SigmaFull)
range(AreaFull)
range(NoiseAdjustBaselineFull)
range(RsqFull)

length(mzError)
length(Sigma)
length(Area)
length(NoiseAdjustBaseline)
length(Rsq)

length(mzErrorFull)
length(SigmaFull)
length(AreaFull)
length(NoiseAdjustBaselineFull)
length(RsqFull)

x=read.csv(FileList[1])
x[1:5,]
y=cbind(mzErrorFull,SigmaFull,AreaFull,NoiseAdjustBaselineFull,RsqFull)
y[1:5,]

plot(mzErrorFull,AreaFull)
plot(SigmaFull,AreaFull)
plot(NoiseAdjustBaselineFull,AreaFull)
plot(mzErrorFull,RsqFull)
plot(SigmaFull,RsqFull)
plot(NoiseAdjustBaselineFull,RsqFull)

hist(mzError, breaks =seq(-.5,.6,.01))
hist(Sigma, breaks =seq(0,.4,.01))
hist(Area, breaks =seq(-20,3000,10))
hist(NoiseAdjustBaseline, breaks =seq(0,200,1))
hist(Rsq, breaks =seq(0,1,.01))

qqnorm(mzError)
qqnorm(Sigma)
qqnorm(Area)
qqnorm(NoiseAdjustBaseline)

#########################################################################################
##Peptide Cutoff/peaks number simulations

length(IsotopicCountFFT('DRVYIHPFHL'))
length(IsotopicCountFFT('DRVYIHPFHL',cutoff=.99))
length(IsotopicCountFFT('DRVYIHPFHL',cutoff=.95))
length(IsotopicCountFFT('DRVYIHPFHL',cutoff=.9))
length(IsotopicCountFFT('DRVYIHPFHL',cutoff=.8))


PepSimulation=as.data.frame(matrix(0, ncol = 2, nrow = 1))
colnames(PepSimulation)=c('Name','Peptide')

PeptideMin=5
PeptideMax=10
SimNumber=50000

for(z in 1:SimNumber){
x = ceiling(runif(1,PeptideMin-1,PeptideMax))
pep=rep(0,x)
for (i in 1:x){
	pep[i] = AA[ceiling(runif(1,0,20))]
}
PepSimulation[z,1] = paste("FakePeptide",z)
PepSimulation[z,2] = paste(pep,collapse = "")
}
length(PepSimulation[,1])
#######################
PeakPoints=list()
for(d in 1:length(PepSimulation[,2])){
PeakPoints[[length(PeakPoints)+1]]=IsotopicCountFFT(PepSimulation[d,2])
}
length(PeakPoints)
length(PeakPoints[[1]])
PeakPoints[1:5]
PeakPoints[[1]][2]
sum(PeakPoints[[1]][1:3])
sum(PeakPoints[[1]])
sum(PeakPoints[[4]][1:3])
##peptides 20^5+20^6+20^7+20^8+20^9+20^10  [1] 1.077895e+13

PeakCounts=NA
for(z in 1:length(PeakPoints)){
PeakCounts[z]=length(PeakPoints[[z]])
}
hist(PeakCounts)

PeakPoints=list()
for(d in 1:length(PepSimulation[,2])){
PeakPoints[[length(PeakPoints)+1]]=IsotopicCountFFT(PepSimulation[d,2],cutoff=.95)
}
PeakCounts=NA
for(z in 1:length(PeakPoints)){
PeakCounts[z]=length(PeakPoints[[z]])
}
hist(PeakCounts)