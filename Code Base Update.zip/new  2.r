rm(list = ls())
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml" 
setwd(FilePath)
source("IsotpoicFitLoad11.R") 
##########
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/HEKAT1TP0"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	LargeSpectraAverage <- getSpec(SpectraImput,mzrange=c(1194,1294))
	print(mean(LargeSpectraAverage[,2]))
	print(range(LargeSpectraAverage[,2]))
	for(j in 1:10){
		SmallSpectraAverage <- getSpec(SpectraImput,mzrange=c(1184+10*j,1194+10*j))
	print(mean(SmallSpectraAverage[,2]))
	print(range(SmallSpectraAverage[,2]))		
	}
}


##########
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Blanks"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	LargeSpectraAverage <- getSpec(SpectraImput,mzrange=c(1194,1294))
	print(mean(LargeSpectraAverage[,2]))
	print(range(LargeSpectraAverage[,2]))
	for(j in 1:10){
		SmallSpectraAverage <- getSpec(SpectraImput,mzrange=c(1184+10*j,1194+10*j))
			print(mean(SmallSpectraAverage[,2]))
	print(range(SmallSpectraAverage[,2]))
	}
}

##########
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/HEKAT1TP0"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	LargeSpectraAverage <- getSpec(SpectraImput,mzrange=c(946,1046))
	print(mean(LargeSpectraAverage[,2]))
	print(range(LargeSpectraAverage[,2]))	
	for(j in 1:10){
		SmallSpectraAverage <- getSpec(SpectraImput,mzrange=c(936+10*j,946+10*j))
			print(mean(SmallSpectraAverage[,2]))
	print(range(SmallSpectraAverage[,2]))
		}
}

##AR(1)##
BL=10
BaselineSample1=BL
BaselineSample2=BL
BaselineSample3=BL
BaselineSample4=BL
##rho=c(.7,.5,.2,-.3,-.51)
rho=.7
##25 au, 
for(i in 1:1500){
BaselineSample1[i+1]=rho*BaselineSample1[i]+runif(1,0,1)
BaselineSample2[i+1]=rho*BaselineSample2[i]+runif(1,0,BL/10)
BaselineSample3[i+1]=rho*BaselineSample3[i]+runif(1,0,BL/100)
BaselineSample4[i+1]=rho*BaselineSample4[i]+runif(1,0,2)

}
plot(seq(0,700,1),BaselineSample1,type='l',col='red',ylim=c(0,16))
abline(h=13.5,col='black')
lines(seq(0,700,1),BaselineSample2,type='l',col='green')
lines(seq(0,700,1),BaselineSample3,type='l',col='blue')
lines(seq(0,700,1),BaselineSample4,type='l',col='yellow')
#################################################################################
#################################################################################
#################################################################################
rm(list = ls())
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml" 
setwd(FilePath)
source("IsotpoicFitLoad11.R") 
##########
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/HEKAT1TP0"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	for(j in 1:10){
		SmallSpectraAverage <- getSpec(SpectraImput,mzrange=c(1184+10*j,1194+10*j))
	print(abs((range(SmallSpectraAverage[,2]))-(mean(SmallSpectraAverage[,2]))))
			
	}
}


##########
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Blanks"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])
	for(j in 1:10){
		SmallSpectraAverage <- getSpec(SpectraImput,mzrange=c(1184+10*j,1194+10*j))
	print(abs((range(SmallSpectraAverage[,2]))-(mean(SmallSpectraAverage[,2]))))
	}
}

##########
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/HEKAT1TP0"
setwd(FilePath)
FileList <- list.files(FilePath,pattern='.*mzXML')

for (i in 1:length(FileList)){
	SpectraImput <- xcmsRaw(FileList[i])	
	for(j in 1:10){
		SmallSpectraAverage <- getSpec(SpectraImput,mzrange=c(936+10*j,946+10*j))
	print(abs((range(SmallSpectraAverage[,2]))-(mean(SmallSpectraAverage[,2]))))
		}
}

##AR(1)##
BL=10
BaselineSample1=BL
BaselineSample2=BL
BaselineSample3=BL
BaselineSample4=BL
##rho=c(.7,.5,.2,-.3,-.51)
rho=.7
##25 au, 
for(i in 1:1500){
BaselineSample1[i+1]=rho*BaselineSample1[i]+runif(1,0,1)
BaselineSample2[i+1]=rho*BaselineSample2[i]+runif(1,0,BL/10)
BaselineSample3[i+1]=rho*BaselineSample3[i]+runif(1,0,BL/100)
BaselineSample4[i+1]=rho*BaselineSample4[i]+runif(1,0,2)

}
plot(seq(0,1500),BaselineSample1,type='l',col='red',ylim=c(0,16))
abline(h=BL,col='black')
lines(seq(0,1500,1),BaselineSample2,type='l',col='green')
lines(seq(0,1500,1),BaselineSample3,type='l',col='blue')
lines(seq(0,1500,1),BaselineSample4,type='l',col='yellow')

xxx1=mean(BaselineSample4)
xxx2=mean(BaselineSample4[100:1400])
abs(range(BaselineSample4[100:1400])-xxx2)
xxx1
xxx2
abline(h=xxx2,col='black')

BL=10
BaselineSample1=BL
for(i in 1:1500){
BaselineSample1[i+1]=.5*BaselineSample1[i]+runif(1,0,10)
}
plot(seq(0,1500),BaselineSample1,type='l',col='red',ylim=c(0,16))
xxx2=mean(BaselineSample1[100:1400])
abs(range(BaselineSample1[100:1400])-xxx2)