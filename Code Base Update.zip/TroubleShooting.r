rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad10.R") 

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/CocktailStock"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')


FileTitle = "CocktailStock2.pdf"
	pdf(file = FileTitle)
	par(mfrow = c(3,2))
	for(i in 1:length(FileList)){
		SpectraImput <- xcmsRaw(FileList[i])
		SpectraAverage <- getSpec(SpectraImput,mzrange=c(1050,1057))
		plot(SpectraAverage[,1],SpectraAverage[,2],type='l',xlab="MZ",ylab="Intensity",main=FileList[i])
		abline(v=1052.5, col='red')
	}
		dev.off()

mzError=seq(.001,.02,.001)
Sigma=seq(.001,.2,.001)

##Single Isotopic Cluster
UnlabeledSequence = c("DRVYIHPFHL")
UnlabeledPeptides = c('AngI')
LabeledSequence = c("RVYIHPFH","DRVYIHPF")
LabeledPeptides = c('Ang-2-9',"AngII")
PeptideInformation=PeptideInfo(UnlabeledPeptides,UnlabeledSequence,LabeledPeptides,LabeledSequence,AQUA=TRUE,Neutron=6,ClusterCut=5)
PeptideInformation=PeptideInformation[2:3,]
PeptideInformation[1,6]=1
PeptideInformation[2,6]=2
FRecord1=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
write.csv(FRecord1,'CocktailStockData.csv')
FRecord1
FileName="CocktailStockplot.pdf"
ViewFitResults2(FRecord1,FileName,PageRow=3,PageCol=2)

########################################################################
##Sequence range 800 - 1300 Ang-1-9 and Ang-2-10 separate serial Dilutions

rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad10.R") 

##Ang-1-9
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions/Ang19"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList2 <- c(FileList[1:3],FileList[16:39],FileList[4:15])

	FileTitle = "Ang19Summary.pdf"
	pdf(file = FileTitle)
	par(mfrow = c(3,2))
	for(i in 1:length(FileList2)){
		SpectraImput <- xcmsRaw(FileList2[i])
		SpectraAverage <- getSpec(SpectraImput,mzrange=c(1188,1195))
		plot(SpectraAverage[,1],SpectraAverage[,2],type='l',ylim=c(0,1400),xlab="MZ",ylab="Intensity",main=FileList[i])
		abline(v=1189.65, col='red')
	}
		dev.off()

mzError=seq(-.31,.3,.001)
Sigma=seq(.001,.25,.001)
UnlabeledSequence = c("DRVYIHPFHL")
UnlabeledPeptides = c('AngI')
LabeledSequence = c("DRVYIHPFH")
LabeledPeptides = c('Ang-1-9')
PeptideInformation=PeptideInfo(UnlabeledPeptides,UnlabeledSequence,LabeledPeptides,LabeledSequence,AQUA=TRUE,Neutron=6,ClusterCut=5)
PeptideInformation=PeptideInformation[2,]
PeptideInformation[1,6]=1
FRecord1=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError,SpectraMin=801,SpectraMax=1250)
write.csv(FRecord1,'Ang19RoughData.csv')
FRecord1
#####
FRecord1=read.csv('Ang19RoughData.csv',stringsAsFactors=FALSE)
FRecord12=rbind(FRecord1[1:3,],FRecord1[16:39,],FRecord1[4:15,])
FRecord12$SpectraCount=1:39
FRecord12=FRecord12[,-1]
#####
FileName="Ang19plot.pdf"
ViewFitResults2(FRecord12,FileName,PageRow=3,PageCol=2)

##Ang2-10
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions/Ang210"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList2 <- c(FileList[1:3],FileList[16:39],FileList[4:15])

	FileTitle = "Ang210Summary.pdf"
	pdf(file = FileTitle)
	par(mfrow = c(3,2))
	for(i in 1:length(FileList2)){
		SpectraImput <- xcmsRaw(FileList2[i])
		SpectraAverage <- getSpec(SpectraImput,mzrange=c(1186,1193))
		plot(SpectraAverage[,1],SpectraAverage[,2],type='l',ylim=c(0,1400),xlab="MZ",ylab="Intensity",main=FileList[i])
		abline(v=1087.71, col='red')
	}
		dev.off()

mzError=seq(-.38,.21,.001)
Sigma=seq(.001,.25,.001)
LabeledSequence = c("RVYIHPFHL")
LabeledPeptides = c('Ang-2-10')
PeptideInformation=PeptideInfo(UnlabeledPeptides,UnlabeledSequence,LabeledPeptides,LabeledSequence,AQUA=TRUE,Neutron=6,ClusterCut=5)
PeptideInformation=PeptideInformation[2,]
PeptideInformation[1,6]=1
FRecord2=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError,SpectraMin=801,SpectraMax=1250)
write.csv(FRecord2,'Ang210RoughData.csv')
FRecord2
#####
FRecord2=read.csv('Ang210RoughData.csv',stringsAsFactors=FALSE)
FRecord22=rbind(FRecord2[1:3,],FRecord2[16:39,],FRecord2[4:15,])
FRecord22$SpectraCount=1:39
FRecord22=FRecord22[,-1]
#####
FileName="Ang210plot.pdf"
ViewFitResults2(FRecord22,FileName,PageRow=3,PageCol=2)

##Secondary Check
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions/Ang19"
setwd(FilePath0)
FRecord1=read.csv('Ang19RoughData.csv',stringsAsFactors=FALSE)
FRecord12=rbind(FRecord1[1:3,],FRecord1[16:39,],FRecord1[4:15,])
FRecord12$SpectraCount=1:39
FRecord12=FRecord12[,-1]
Ang19Check=PeakAreaHeightScan(FRecord12)
write.csv(Ang19Check,'Ang19CheckData.csv')

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions/Ang210"
setwd(FilePath0)
FRecord2=read.csv('Ang210RoughData.csv',stringsAsFactors=FALSE)
FRecord22=rbind(FRecord2[1:3,],FRecord2[16:39,],FRecord2[4:15,])
FRecord22$SpectraCount=1:39
FRecord22=FRecord22[,-1]
Ang210Check=PeakAreaHeightScan(FRecord22)
write.csv(Ang210Check,'Ang210CheckData.csv')

fmolsDilution=c(10000,10000,10000,5000,5000,5000,1000,1000,1000,500,500,500,250,250,250,125,125,125,62.5,62.5,62.5,31.25,31.25,31.25,15.625,15.625,15.625,7.8125,7.8125,7.8125,3.90625,3.90625,3.90625,1.953125,1.953125,1.953125,0.9765625,0.9765625,0.9765625)
SummaryData1=cbind(FRecord22[,4],FRecord22[,9],Ang210Check[,6],fmolsDilution)
SummaryData2=cbind(FRecord12[,4],FRecord12[,9],Ang19Check[,6],fmolsDilution)

#FileTitle = ""
#pdf(file = FileTitle)
par(mfrow = c(2,3))
plot(SummaryData1[,4],SummaryData1[,2],xlab="fmols",ylab="Estimated Area Prediction",main="AQUA Ang-2-10 Area")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(as.numeric(SummaryData1[,2]),3,13)),col="red")
legend(1,800,"mean",col="red",lwd=1)
plot(SummaryData1[,4],SummaryData1[,2],log="x",xlab="log fmols",ylab="Estimated Area Prediction",main="AQUA Ang-2-10 Area")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(as.numeric(SummaryData1[,2]),3,13)),col="red")
legend(1,800,"mean",col="red",lwd=1)
plot(SummaryData1[,4],SummaryData1[,2],log="xy",xlab="log fmols",ylab="log Estimated Area Prediction",main="AQUA Ang-2-10 Area")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(as.numeric(SummaryData1[,2]),3,13)),col="red")
legend(1,800,"mean",col="red",lwd=1)

plot(SummaryData2[,4],SummaryData2[,2],xlab="fmols",ylab="Estimated Area Prediction",main="AQUA Ang-1-9 Area")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(as.numeric(SummaryData2[,2]),3,13)),col="red")
legend(1,500,"mean",col="red",lwd=1)
plot(SummaryData2[,4],SummaryData2[,2],log="x",xlab="log fmols",ylab="Estimated Area Prediction",main="AQUA Ang-1-9 Area")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(as.numeric(SummaryData2[,2]),3,13)),col="red")
legend(1,500,"mean",col="red",lwd=1)
plot(SummaryData2[,4],SummaryData2[,2],log="xy",xlab="log fmols",ylab="log Estimated Area Prediction",main="AQUA Ang-1-9 Area")
lines(colMeans(matrix(fmolsDilution,3,13)),colMeans(matrix(as.numeric(SummaryData2[,2]),3,13)),col="red")
legend(1,800,"mean",col="red",lwd=1)

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngSerialDilutions"
setwd(FilePath0)
TotalData=rbind(SummaryData1,SummaryData2)
colnames(TotalData)=c("File Title","Estimated Area","3 peak intensity sum","fmols per sample")
write.csv(TotalData,'DataSummary.csv')