##
#Looking at variance of the residuals for all collected spectra, for error modeling
##
rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad7.R") 
######################################
Sigma=seq(.05,.3,.01)
mzError=seq(-.5,.5,.01)
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml/ExpandedParameters3"
######################################
FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/2nd NepAng"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'2nd NepAng.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/mPod P28 1h run"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'mPod P28 1h run.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngMixExperiments"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'AngMixExperiments.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/mPod P33-rNEP A2-10"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'mPod P33-rNEP A2-10.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/MPodo A2-10 sch"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'MPodo A2-10 sch.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/MPodoSCHAng1"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'MPodoSCHAng1.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Nep2-2-10Deg"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'NepDegAngI.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/NepDegAngI"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'NepDegAngI.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/2nd NepAng"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'2nd NepAng.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/mPod P28 1h run"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'mPod P28 1h run.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/rAPA 100ng 0626-0628"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'rAPA 100ng 0626-0628.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/rAPA new 100ng 0629"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'rAPA new 100ng 0629.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/rAPA-rAPN 0713-0719"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'rAPA-rAPN 0713-0719.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/rAPN 100ng 0727-0730"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'rAPN 100ng 0727-0730.csv')
#########################################################################
#########################################################################
FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/POD Converted"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'POD Converted.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/PODData0511"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'PODData0511.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/PODData0511/Ang-(1-7) Deg"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'Ang-(1-7) Deg.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/PODData0511/Ang-(1-9) and Ang-(2-10) Nep exp"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'Ang-(1-9) and Ang-(2-10) Nep exp.csv')

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/PODData0511/Ang-(1-9) Deg"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
EditedResults2=QuickEditResults2(EditedResults,5)
setwd(FilePath0)
write.csv(EditedResults2,'Ang-(1-9) Deg.csv')


#################################################################
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*csv')
length(FileList)
FileList=FileList[-6]
FileList=FileList[-6]
Compile=data.frame()
for (i in 1:length(FileList)){
	a1 = read.csv(FileList[i])	
	Compile=rbind(Compile,a1)
}
length(Compile[,1])
##EditedResults2=QuickEditResults2(EditedResults,50)???
write.csv(Compile,'CompiledResultsForVarEst2.csv')
##################################################################
##Compile=read.csv('CompiledResultsForVarEst.csv')
##Compile=Compile[,-1]
##plot(Compile[,11],Compile[,14])
##plot(density(log(Compile[,11])),type='l')
##plot(Compile[,11],Compile[,14],log='xy')##LOG TRANSFORM
##library(scatterplot3d)
##scatterplot3d(Compile[,8],Compile[,9],Compile[,12])
hist(Compile[,8])
hist(Compile[,9])
mean(unique(Compile[,13]))
mean(unique(Compile[,14]))
sqrt(mean(unique(Compile[,14])))

mean(log(Compile[,11]))
sqrt(var(log(Compile[,11])))
z=density(log(Compile[,11]))
answer=glm.fit(z$x,z$y,family=gaussian())
x=z$x
y=dnorm(x,3.279316,0.6534015)
y2=dlnorm(x,3.279316,0.6534015)
plot(x,y,type='l')
points(z$x,z$y)
##################################################################################
mean(unique(Compile[,14]))
median(unique(Compile[,14]))
plot(Compile[,12],Compile[,14])
plot(density(log(unique(Compile[,14]))),type='l')
z=density(log(unique(Compile[,14])))
input=log(unique(Compile[,14]))
curve=cbind(z$x,z$y)

library(mixtools)
results=normalmixEM(input, mu=c(.23,5.5), sigma=c(1.35,1.46),lambda=c(.45,.55),epsilon = 1e-6,,ECM = TRUE)
test=rnormmix(1000,mu=c(.23,5.5),sigma=c(1.35,1.46),lambda=c(.46,.54))
plot(density(test))
points(curve)
test2=rnormmix(1000,mu=c(0.3620344, 5.3593586),sigma=c(1.237027, 1.547924),lambda=c(0.4288417, 0.5711583))
test3=rnormmix(1000,mu=c(0.4770443, 4.7083164),sigma=c(1.028894, 1.691483),lambda=c(0.5313373, 0.4686627))
plot(density(test2))
plot(density(test3))
points(curve)

##exp()of x axis to get variance
(Compile[order(Compile[,14]),])[1400:1419,]

####looking at high residual variances, can be explained looking at spectra
> FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/MPodoSCHAng1"
> setwd(FilePath2)
> FileList <- list.files(FilePath2,pattern='.*mzXML')
> length(FileList)
> SpectraImput <- xcmsRaw(FileList[11])
> SpectraAverage <- getSpec(SpectraImput,mzrange=c(1295,1301))
> plot(SpectraAverage,type='l')
