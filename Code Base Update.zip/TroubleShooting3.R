######################################
######################################
######################################
##210:210A
rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad11.R") 

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang210Serial"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList

mzError=seq(-.03,.44,.001)
Sigma=seq(.08,.31,.001)

UnlabeledSequence = c("RVYIHPFHL")
UnlabeledPeptides = c('Ang-2-10')
LabeledSequence = c("RVYIHPFHL")
LabeledPeptides = c('Ang-2-10')
PeptideInformation=PeptideInfo(UnlabeledPeptides,UnlabeledSequence,LabeledPeptides,LabeledSequence,AQUA=TRUE,Neutron=6,ClusterCut=5)
PeptideInformation

FRecord1=MultiPeakPeptideScan(FileList[16:60],PeptideInformation,Sigma,mzError,SpectraMin=801,SpectraMax=1250,NormalizeMethod="Ion")
write.csv(FRecord1,"Ang210Comparison.csv")
range(FRecord1$mzError)
range(FRecord1$Sigma)
#######################################
rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad11.R") 

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang210Serial"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')

ViewRawSpectra("SpotTest.pdf",FileList[1:15],SpectraStart=1181,SpectraFinish=1196)

mzError=seq(-.019,.51,.001)
Sigma=seq(.039,.261,.001)

UnlabeledSequence = c("RVYIHPFHL")
UnlabeledPeptides = c('Ang-2-10')
LabeledSequence = c("RVYIHPFHL")
LabeledPeptides = c('Ang-2-10')
PeptideInformation=PeptideInfo(UnlabeledPeptides,UnlabeledSequence,LabeledPeptides,LabeledSequence,AQUA=TRUE,Neutron=6,ClusterCut=5)
PeptideInformation=PeptideInformation[-2,]

FRecord1=MultiPeakPeptideScan(FileList[1:15],PeptideInformation,Sigma,mzError,SpectraMin=801,SpectraMax=1250,NormalizeMethod="Ion")
write.csv(FRecord1,"SpotTechComparison.csv")
range(FRecord1$mzError)
range(FRecord1$Sigma)
ViewFitResults(FRecord1,"Ang210Compare",SpectraStart=1150,SpectraFinish=1200)
#######################################
rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad11.R") 

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/PlateTest"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')

ViewRawSpectra("PlateTestRaw.pdf",FileList,SpectraStart=1181,SpectraFinish=1196)

mzError=seq(.16,.51,.001)
Sigma=seq(.07,.31,.001)
#> range(FRecord1$mzError)
#[1] 0.17 0.50
#> range(FRecord1$Sigma)
#[1] 0.08 0.30

UnlabeledSequence = c("RVYIHPFHL")
UnlabeledPeptides = c('Ang-2-10')
LabeledSequence = c("RVYIHPFHL")
LabeledPeptides = c('Ang-2-10')
PeptideInformation=PeptideInfo(UnlabeledPeptides,UnlabeledSequence,LabeledPeptides,LabeledSequence,AQUA=TRUE,Neutron=6,ClusterCut=5)
PeptideInformation=PeptideInformation[-2,]

FRecord1=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError,SpectraMin=801,SpectraMax=1250,NormalizeMethod="Ion")
write.csv(FRecord1,"PlateTest.csv")
range(FRecord1$mzError)
range(FRecord1$Sigma)

ViewFitResults(FRecord1,"PlateTest.pdf",SpectraStart=1150,SpectraFinish=1200)
################################################
##PeakScan
rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad11.R") 

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/PlateTest"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileThree=read.csv("PlateTest.csv",stringsAsFactors=FALSE)
FileThree=FileThree[,-1]
FRecord1=PeakAreaHeightScan(FileThree) 

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang210Serial"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileOne=read.csv("Ang210Comparison.csv",stringsAsFactors=FALSE)
FileOne=FileOne[,-1]
FileTwo=read.csv("SpotTechComparison.csv",stringsAsFactors=FALSE)
FileTwo=FileTwo[,-1]
FullRecord1=rbind(FileOne,FileTwo)
FRecord2=PeakAreaHeightScan(FullRecord1)

FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop"
setwd(FilePath)
write.csv(FRecord1,"PlateTestPeakHeight.csv")
write.csv(FRecord2,"210SerialPeakHeight.csv")
###################################################
rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad11.R") 

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang210Ang19 071013"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')

ViewRawSpectra("Ang210Ang19Raw.pdf",FileList,SpectraStart=1181,SpectraFinish=1196)

UnlabeledSequence = c("RVYIHPFHL")
UnlabeledPeptides = c('Ang-2-10')
LabeledSequence = c("RVYIHPFHL","DRVYIHPFH")
LabeledPeptides = c('Ang-2-10','Ang-1-9')
PeptideInformation = PeptideInfo(UnlabeledPeptides,UnlabeledSequence,LabeledPeptides,LabeledSequence,AQUA=TRUE,Neutron=6,ClusterCut=5)
PeptideInformation
PeptideInformation2=PeptideInformation[-1,]

mzError=seq(-.15,.42,.001)
Sigma=seq(.12,.31,.001)
FRecord1=MultiPeakPeptideScan(FileList[6:15],PeptideInformation2,Sigma,mzError,SpectraMin=801,SpectraMax=1250,NormalizeMethod="Ion")
range(FRecord1$mzError)
range(FRecord1$Sigma)

mzError=seq(-.16,.41,.01)
Sigma=seq(.11,.31,.01)
FRecord2=MultiPeakPeptideScan(FileList[16:20],PeptideInformation,Sigma,mzError,SpectraMin=801,SpectraMax=1250,NormalizeMethod="Ion")
range(FRecord1$mzError)
range(FRecord1$Sigma)

TRecord=rbind(FRecord1,FRecord2)
ViewFitResults(FRecord1,"Ang210RatioFit2.pdf",SpectraStart=1150,SpectraFinish=1200)

write.csv(FRecord1,"Ang210Ratio2.csv")
###############################################
rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad11.R")

UnlabeledSequence = c("RVYIHPFHL")
UnlabeledPeptides = c('Ang-2-10')
LabeledSequence = c("RVYIHPFHL","DRVYIHPFH")
LabeledPeptides = c('Ang-2-10','Ang-1-9')
PeptideInformation = PeptideInfo(UnlabeledPeptides,UnlabeledSequence,LabeledPeptides,LabeledSequence,AQUA=TRUE,Neutron=6,ClusterCut=5)
PeptideInformation
PeptideInformation2=PeptideInformation[-1,]
 
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang210Ang19 071113/Full"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList

mzError=seq(-.001,.43,.001)
Sigma=seq(.12,.31,.001)
FRecord1=MultiPeakPeptideScan(FileList[1:13],PeptideInformation2,Sigma,mzError,SpectraMin=801,SpectraMax=1250,NormalizeMethod="Ion")
range(FRecord1$mzError)
range(FRecord1$Sigma)

mzError=seq(-.14,.32,.01)
Sigma=seq(.07,.28,.01)
FRecord2=MultiPeakPeptideScan(FileList[14:23],PeptideInformation,Sigma,mzError,SpectraMin=801,SpectraMax=1250,NormalizeMethod="Ion")
range(FRecord2$mzError)
range(FRecord2$Sigma)
#ViewRawSpectra("Ang210Ang19Raw.pdf",FileList,SpectraStart=1181,SpectraFinish=1196)

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang210Ang19 071113/Partial"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList

mzError=seq(-.001,.48,.001)
Sigma=seq(.07,.31,.001)
FRecord3=MultiPeakPeptideScan(FileList[1:12],PeptideInformation2,Sigma,mzError,SpectraMin=801,SpectraMax=1250,NormalizeMethod="Ion")
range(FRecord3$mzError)
range(FRecord3$Sigma)

mzError=seq(-.06,.49,.001)
Sigma=seq(.07,.23,.001)
FRecord4=MultiPeakPeptideScan(FileList[13:21],PeptideInformation,Sigma,mzError,SpectraMin=801,SpectraMax=1250,NormalizeMethod="Ion")
range(FRecord4$mzError)
range(FRecord4$Sigma)
#ViewRawSpectra("Ang210Ang19Raw.pdf",FileList,SpectraStart=1181,SpectraFinish=1196)

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang210Ang19 071113/Full"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
mzError=seq(-.14,.32,.01)
Sigma=seq(.07,.28,.01)
FRecord2=MultiPeakPeptideScan(FileList[14:23],PeptideInformation,Sigma,mzError,SpectraMin=801,SpectraMax=1250,NormalizeMethod="Ion")

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang210Ang19 071113/Partial"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
mzError=seq(-.06,.49,.001)
Sigma=seq(.07,.23,.001)
FRecord4=MultiPeakPeptideScan(FileList[13:21],PeptideInformation,Sigma,mzError,SpectraMin=801,SpectraMax=1250,NormalizeMethod="Ion")

FRecord1
FRecord2
FRecord3
FRecord4
TotalRecord=rbind(FRecord1,FRecord2,FRecord3,FRecord4)

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang210Ang19 071113/Partial"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang210Ang19 071113/Full"
setwd(FilePath0)
write.csv(TotalRecord,"Ang210Ang19_071113.csv")
ViewFitResults(FRecord1,"Ang210Ang19Fit1.pdf",SpectraStart=1150,SpectraFinish=1200)
ViewFitResults(FRecord2,"Ang210Ang19Fit2.pdf",SpectraStart=1150,SpectraFinish=1200)

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang210Ang19 071113/Partial"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
ViewFitResults(FRecord3,"Ang210Ang19Fit3.pdf",SpectraStart=1150,SpectraFinish=1200)

