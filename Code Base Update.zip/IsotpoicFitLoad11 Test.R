##Base code 11 check, normalization method inclusion
##Changed PeptideInformation base information and fleshed out normalization
rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad11.R") 

FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngDil052413"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList
BaseData=read.csv('AngDil052413Data3.csv',stringsAsFactors=FALSE)

UnlabeledSequence = c("DRVYIHPFH","RVYIHPFHL")
UnlabeledPeptides = c('Ang-1-9','Ang-2-10')
PeptideInformation=PeptideInfo(UnlabeledPeptides,UnlabeledSequence,LabeledPeptides,LabeledSequence,AQUA=FALSE,Neutron=6,ClusterCut=5)
PeptideInformation

mzError=seq(.15,.59,.01)
Sigma=seq(.06,.18,.01)
length(mzError)*length(Sigma)

FRecord1=MultiPeakPeptideScan(FileList[1:9],PeptideInformation,Sigma,mzError,SpectraMin=801,SpectraMax=1250,RsqMin=.7,NormalizeMethod="Peak")
FRecord2=MultiPeakPeptideScan(FileList[1:9],PeptideInformation,Sigma,mzError,SpectraMin=801,SpectraMax=1250,RsqMin=.7,NormalizeMethod=c("Peptide","RVYIHPFHL"))
FRecord3=MultiPeakPeptideScan(FileList[1:9],PeptideInformation,Sigma,mzError,SpectraMin=801,SpectraMax=1250,RsqMin=.7,NormalizeMethod="Ion")
FRecord4=MultiPeakPeptideScan(FileList[1:9],PeptideInformation,Sigma,mzError,SpectraMin=801,SpectraMax=1250,RsqMin=.7,NormalizeMethod="NoNormalization")

cbind(FRecord1[,1],FRecord1[,4],FRecord1[,9],FRecord1[,14],FRecord1[,15],FRecord2[,9],FRecord2[,14],FRecord2[,15],FRecord3[,9],FRecord3[,14],FRecord3[,15],FRecord4[,9],FRecord4[,14],FRecord4[,15])
##################################################################################
rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad11.R") 
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/Ang210Ang19 071013"
setwd(FilePath0)
FileList <- list.files(FilePath0,pattern='.*mzXML')
FileList
TestFit=read.csv("Ang210Ang19.csv",stringsAsFactors=FALSE,sep = "\t")
TestFit=TestFit[,-1]
TestFit
ViewRawSpectra("Ang210Ang19Raw.pdf",FileList,SpectraStart=1181,SpectraFinish=1196)
ViewFitResults(TestFit,"Ang210Ang19Fit.pdf",SpectraStart=1150,SpectraFinish=1200)
##################################################################################
