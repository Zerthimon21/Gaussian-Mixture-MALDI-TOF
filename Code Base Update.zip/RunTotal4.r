##
#Looking at variance of the residuals for all collected spectra, for error modeling
##
rm(list = ls())
library(xcms)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml"
setwd(FilePath)
source("IsotpoicFitLoad9.R") 
######################################
Sigma=seq(.01,.3,.01)
mzError=seq(-.7,.7,.01)
FilePath0 <- "C:/Documents and Settings/Zerthimon21/Desktop/mzxml/ExpandedParameters4"
######################################
PeptideInformation


FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/mPod P28 1h run"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
FRecord=MultiPeakPeptideScan(FileList,PeptideInformation,Sigma,mzError)
EditedResults=QuickEditResults(FRecord,.7)
setwd(FilePath0)
write.csv(EditedResults,'mPod P28 1h run.csv')


FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra"
setwd(FilePath2)
FileList <- list.files(FilePath2,pattern='.*mzXML')
SpectraImput <- xcmsRaw(FileList[1])
SpectraAverage <- getSpec(SpectraImput,mzrange=c(1170,1350))
plot(SpectraAverage[,1],SpectraAverage[,2],type='l',xlab="MZ",ylab="Intensity",main="Figure 1: Fitting Overlapping Spectra")





FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/2nd NepAng"

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/AngMixExperiments"

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/mPod P33-rNEP A2-10"

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/MPodo A2-10 sch"

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/MPodoSCHAng1"

FilePath2 <- "C:/Documents and Settings/Zerthimon21/Desktop/spectra/NepDegAngI"
