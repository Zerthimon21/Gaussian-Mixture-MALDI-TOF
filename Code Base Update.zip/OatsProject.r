##Oates ANN/SVM work
rm(list = ls())
library(e1071)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/Oats ANN" 
setwd(FilePath)
OatsData = read.csv("OatsUrineData.csv")

##for iteration randomize 1/0 2:1 in OatsData[,2] for train/test data

##Start Time Point
ModelOne=cbind(OatsData[,2],OatsData[,24],OatsData[,7],OatsData[,9],OatsData[,12],OatsData[,14],OatsData[,16],OatsData[,21],OatsData[,26:43])
ModelOne[1:4,]
ModelOne=ModelOne[-c(1,2,3),]
TrainModelOne = subset(ModelOne, !(ModelOne[,2] == 1))
TestModelOne = subset(ModelOne, !(ModelOne[,2] == 0))
x <- TrainModelOne[,3:8]
y <- TrainModelOne[,2] ##Responce/outcome
model <- svm(x, y,type="C-classification")

print(model)
summary(model)

pred <- predict(model, x)
table(pred, y)

##Three Month
ModelTwo=cbind(OatsData[,2],OatsData[,24],OatsData[,7],OatsData[,10],OatsData[,13],OatsData[,15],OatsData[,17],OatsData[,21],OatsData[,22],OatsData[,44:61])
ModelTwo[1:4,]
ModelTwo=ModelTwo[-c(1,2,3),]
TrainModelTwo = subset(ModelTwo, !(ModelTwo[,2] == 1))
TestModelTwo = subset(ModelTwo, !(ModelTwo[,2] == 0))

##Difference
ModelThree=cbind(OatsData[,2],OatsData[,24],OatsData[,7],OatsData[,21],OatsData[,62:84])
ModelThree[1:4,]
ModelThree=ModelThree[-c(1,2,3),]
TrainModelThree = subset(ModelThree, !(ModelThree[,2] == 1))
TestModelThree = subset(ModelThree, !(ModelThree[,2] == 0))

##Start + Three Month
ModelFour=cbind(OatsData[,2],OatsData[,24],OatsData[,7],OatsData[,9],OatsData[,12],OatsData[,14],OatsData[,16],OatsData[,21],OatsData[,26:43],OatsData[,10],OatsData[,13],OatsData[,15],OatsData[,17],OatsData[,21],OatsData[,22],OatsData[,44:61])
ModelFour[1:4,]
ModelFour=ModelFour[-c(1,2,3),]
TrainModelFour = subset(ModelFour, !(ModelFour[,2] == 1))
TestModelFour = subset(ModelFour, !(ModelFour[,2] == 0))

#########################################################################

rm(list = ls())
library(e1071)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/Oats ANN" 
setwd(FilePath)
OatsData = read.csv("OatsUrineData.csv")

##for iteration randomize 1/0 2:1 in OatsData[,2] for train/test data

##Start Time Point
ModelOne=cbind(OatsData[,2],OatsData[,24],OatsData[,7],OatsData[,9],OatsData[,12],OatsData[,14],OatsData[,16],OatsData[,21],OatsData[,26:43])
length(ModelOne[1,])
ModelOne[1:4,]
ModelOne=ModelOne[-c(1,2,3),]
TrainModelOne = subset(ModelOne, !(ModelOne[,1] == 0))##Train 95
TestModelOne = subset(ModelOne, !(ModelOne[,1] == 1))##Test 49
dim(TrainModelOne)
dim(TestModelOne)
x1 <- TrainModelOne[,3:26]
y1 <- TrainModelOne[,2] ##Responce/outcome
x2 <- TestModelOne[,3:26]
y2 <- TestModelOne[,2] ##Responce/outcome
model1 <- svm(x1, y1,type="C-classification",kernel="linear") ##Train SVM
print(model1)
pred1 <- predict(model1, x1)
table(pred1, y1)
pred2 <- predict(model1, x2)
table(pred2, y2)

vartab=table(pred2, y2)

model1 <- svm(x1, y1,type="C-classification",kernel="radial")
print(model1)
pred1 <- predict(model1, x1)
table(pred1, y1)
pred2 <- predict(model1, x2)
table(pred2, y2)

model1 <- svm(x1, y1,type="C-classification",kernel="polynomial")
print(model1)
pred1 <- predict(model1, x1)
table(pred1, y1)
pred2 <- predict(model1, x2)
table(pred2, y2)

model1 <- svm(x1, y1,type="C-classification",kernel="sigmoid")
print(model1)
pred1 <- predict(model1, x1)
table(pred1, y1)
pred2 <- predict(model1, x2)
table(pred2, y2)
###############################################################################
###############################################################################
###############################################################################
rm(list = ls())
library(e1071)
FilePath <- "C:/Documents and Settings/Zerthimon21/Desktop/Oats ANN" 
setwd(FilePath)
OatsData = read.csv("OatsUrineData.csv")

Interation=5000
selection=sequence(144)
SVMTrain=rep(0,Interation)
SVMSummary=rep(0,Interation)
KernalType=c("linear","radial","polynomial","sigmoid")

##Start Time Point
ModelOne=cbind(OatsData[,2],OatsData[,24],OatsData[,7],OatsData[,9],OatsData[,12],OatsData[,14],OatsData[,16],OatsData[,21],OatsData[,26:43])
ModelOne=ModelOne[-c(1,2,3),]

for(j in 1:4){
for(i in 1:Interation){
	TrainSet=sample(selection,144,replace = FALSE)
	ModelOneMix=ModelOne[TrainSet,]

	TrainModel=ModelOneMix[1:95,]
	TrainModel[1,]=1
	TestModel=ModelOneMix[96:144,]
	TestModel[1,]=0
	
	x1 <- TrainModel[,3:26]
	y1 <- TrainModel[,2] ##Responce/outcome
	x2 <- TestModel[,3:26]
	y2 <- TestModel[,2] ##Responce/outcome
	model1 <- svm(x1, y1,type="C-classification",kernel=KernalType[j]) ##Train SVM
	pred1 <- predict(model1, x1)
	predtable1 = table(pred1, y1)
	pred2 <- predict(model1, x2)
	predtable2 = table(pred2, y2)
	SVMTrain[i]=(predtable1[1,1]+predtable1[2,2])/(sum(predtable1))
	SVMSummary[i]=(predtable2[1,1]+predtable2[2,2])/(sum(predtable2))	
}
print(KernalType[j])
print("SVMTrain")
print(mean(SVMTrain))
print(range(SVMTrain))
print("SVMSummary")
print(mean(SVMSummary))
print(range(SVMSummary))
}

UrCreModel=ModelOne[,-4]
UrCreModel[,8:25]=UrCreModel[,8:25]/ModelOne[,4]
ModelOne=UrCreModel

for(j in 1:4){
for(i in 1:Interation){
	TrainSet=sample(selection,144,replace = FALSE)
	ModelOneMix=ModelOne[TrainSet,]

	TrainModel=ModelOneMix[1:95,]
	TrainModel[1,]=1
	TestModel=ModelOneMix[96:144,]
	TestModel[1,]=0
	
	x1 <- TrainModel[,3:25]
	y1 <- TrainModel[,2] ##Responce/outcome
	x2 <- TestModel[,3:25]
	y2 <- TestModel[,2] ##Responce/outcome
	model1 <- svm(x1, y1,type="C-classification",kernel=KernalType[j]) ##Train SVM
	pred1 <- predict(model1, x1)
	predtable1 = table(pred1, y1)
	pred2 <- predict(model1, x2)
	predtable2 = table(pred2, y2)
	SVMTrain[i]=(predtable1[1,1]+predtable1[2,2])/(sum(predtable1))
	SVMSummary[i]=(predtable2[1,1]+predtable2[2,2])/(sum(predtable2))	
}
print(KernalType[j])
print("SVMTrain")
print(mean(SVMTrain))
print(range(SVMTrain))
print("SVMSummary")
print(mean(SVMSummary))
print(range(SVMSummary))
}


########################
ModelOne=cbind(OatsData[,2],OatsData[,24],OatsData[,7],OatsData[,10],OatsData[,13],OatsData[,15],OatsData[,17],OatsData[,21],OatsData[,22],OatsData[,44:61])
ModelOne=ModelOne[-c(1,2,3),]
dim(ModelOne)
for(j in 1:4){
for(i in 1:Interation){
	TrainSet=sample(selection,144,replace = FALSE)
	ModelOneMix=ModelOne[TrainSet,]

	TrainModel=ModelOneMix[1:95,]
	TrainModel[1,]=1
	TestModel=ModelOneMix[96:144,]
	TestModel[1,]=0
	
	x1 <- TrainModel[,3:27]
	y1 <- TrainModel[,2] ##Responce/outcome
	x2 <- TestModel[,3:27]
	y2 <- TestModel[,2] ##Responce/outcome
	model1 <- svm(x1, y1,type="C-classification",kernel=KernalType[j]) ##Train SVM
	pred1 <- predict(model1, x1)
	predtable1 = table(pred1, y1)
	pred2 <- predict(model1, x2)
	predtable2 = table(pred2, y2)
	SVMTrain[i]=(predtable1[1,1]+predtable1[2,2])/(sum(predtable1))
	SVMSummary[i]=(predtable2[1,1]+predtable2[2,2])/(sum(predtable2))	
}
print(KernalType[j])
print("SVMTrain")
print(mean(SVMTrain))
print(range(SVMTrain))
print("SVMSummary")
print(mean(SVMSummary))
print(range(SVMSummary))
}

ModelOne=cbind(OatsData[,2],OatsData[,24],OatsData[,7],OatsData[,10],OatsData[,13],OatsData[,15],OatsData[,17],OatsData[,21],OatsData[,22],OatsData[,44:61])
ModelOne=ModelOne[-c(1,2,3),]
ModelOne=subset(ModelOne, !(ModelOne[,4] == 0))

UrCreModel=ModelOne[,-4]
UrCreModel[,9:26]=UrCreModel[,9:26]/ModelOne[,4]

ModelOne=UrCreModel
dim(ModelOne)
selection=sequence(142)

for(j in 1:4){
for(i in 1:Interation){
	TrainSet=sample(selection,142,replace = FALSE) ##Should be set to number of rows
	ModelOneMix=ModelOne[TrainSet,]

	TrainModel=ModelOneMix[1:93,]
	TrainModel[1,]=1
	TestModel=ModelOneMix[94:142,]
	TestModel[1,]=0
	
	x1 <- TrainModel[,3:26]
	y1 <- TrainModel[,2] ##Responce/outcome
	x2 <- TestModel[,3:26]
	y2 <- TestModel[,2] ##Responce/outcome
	model1 <- svm(x1, y1,type="C-classification",kernel=KernalType[j]) ##Train SVM
	pred1 <- predict(model1, x1)
	predtable1 = table(pred1, y1)
	pred2 <- predict(model1, x2)
	predtable2 = table(pred2, y2)
	SVMTrain[i]=(predtable1[1,1]+predtable1[2,2])/(sum(predtable1))
	SVMSummary[i]=(predtable2[1,1]+predtable2[2,2])/(sum(predtable2))	
}
print(KernalType[j])
print("SVMTrain")
print(mean(SVMTrain))
print(range(SVMTrain))
print("SVMSummary")
print(mean(SVMSummary))
print(range(SVMSummary))
}
########################
ModelOne=cbind(OatsData[,2],OatsData[,24],OatsData[,7],OatsData[,21],OatsData[,62:84])
ModelOne=ModelOne[-c(1,2,3),]
dim(ModelOne)
for(j in 1:4){
for(i in 1:Interation){
	TrainSet=sample(selection,144,replace = FALSE)
	ModelOneMix=ModelOne[TrainSet,]

	TrainModel=ModelOneMix[1:95,]
	TrainModel[1,]=1
	TestModel=ModelOneMix[96:144,]
	TestModel[1,]=0
	
	x1 <- TrainModel[,3:27]
	y1 <- TrainModel[,2] ##Responce/outcome
	x2 <- TestModel[,3:27]
	y2 <- TestModel[,2] ##Responce/outcome
	model1 <- svm(x1, y1,type="C-classification",kernel=KernalType[j]) ##Train SVM
	pred1 <- predict(model1, x1)
	predtable1 = table(pred1, y1)
	pred2 <- predict(model1, x2)
	predtable2 = table(pred2, y2)
	SVMTrain[i]=(predtable1[1,1]+predtable1[2,2])/(sum(predtable1))
	SVMSummary[i]=(predtable2[1,1]+predtable2[2,2])/(sum(predtable2))	
}
print(KernalType[j])
print("SVMTrain")
print(mean(SVMTrain))
print(range(SVMTrain))
print("SVMSummary")
print(mean(SVMSummary))
print(range(SVMSummary))
}

ModelOne=cbind(OatsData[,2],OatsData[,24],OatsData[,7],OatsData[,10],OatsData[,9],OatsData[,21],OatsData[,44:61],OatsData[,26:43])
ModelOne=ModelOne[-c(1,2,3),]
ModelOne=subset(ModelOne, !(ModelOne[,4] == 0))
dim(ModelOne)
ModelOne[1:5,]

ModelOne=cbind(ModelOne[,1],ModelOne[,2],ModelOne[,3],ModelOne[,6],ModelOne[,25:42]/ModelOne[,4]-ModelOne[,7:24]/ModelOne[,5])
dim(ModelOne)
selection=sequence(142)

for(j in 1:4){
for(i in 1:Interation){
	TrainSet=sample(selection,142,replace = FALSE)
	ModelOneMix=ModelOne[TrainSet,]

	TrainModel=ModelOneMix[1:93,]
	TrainModel[1,]=1
	TestModel=ModelOneMix[94:142,]
	TestModel[1,]=0
	
	x1 <- TrainModel[,3:22]
	y1 <- TrainModel[,2] ##Responce/outcome
	x2 <- TestModel[,3:22]
	y2 <- TestModel[,2] ##Responce/outcome
	model1 <- svm(x1, y1,type="C-classification",kernel=KernalType[j]) ##Train SVM
	pred1 <- predict(model1, x1)
	predtable1 = table(pred1, y1)
	pred2 <- predict(model1, x2)
	predtable2 = table(pred2, y2)
	SVMTrain[i]=(predtable1[1,1]+predtable1[2,2])/(sum(predtable1))
	SVMSummary[i]=(predtable2[1,1]+predtable2[2,2])/(sum(predtable2))	
}
print(KernalType[j])
print("SVMTrain")
print(mean(SVMTrain))
print(range(SVMTrain))
print("SVMSummary")
print(mean(SVMSummary))
print(range(SVMSummary))
}
########################
ModelOne=cbind(OatsData[,2],OatsData[,24],OatsData[,7],OatsData[,9],OatsData[,12],OatsData[,14],OatsData[,16],OatsData[,21],OatsData[,26:43],OatsData[,10],OatsData[,13],OatsData[,15],OatsData[,17],OatsData[,21],OatsData[,22],OatsData[,44:61])
ModelOne=ModelOne[-c(1,2,3),]
dim(ModelOne)
for(j in 1:4){
for(i in 1:Interation){
	TrainSet=sample(selection,144,replace = FALSE)
	ModelOneMix=ModelOne[TrainSet,]

	TrainModel=ModelOneMix[1:95,]
	TrainModel[1,]=1
	TestModel=ModelOneMix[96:144,]
	TestModel[1,]=0
	
	x1 <- TrainModel[,3:50]
	y1 <- TrainModel[,2] ##Responce/outcome
	x2 <- TestModel[,3:50]
	y2 <- TestModel[,2] ##Responce/outcome
	model1 <- svm(x1, y1,type="C-classification",kernel=KernalType[j]) ##Train SVM
	pred1 <- predict(model1, x1)
	predtable1 = table(pred1, y1)
	pred2 <- predict(model1, x2)
	predtable2 = table(pred2, y2)
	SVMTrain[i]=(predtable1[1,1]+predtable1[2,2])/(sum(predtable1))
	SVMSummary[i]=(predtable2[1,1]+predtable2[2,2])/(sum(predtable2))	
}
print(KernalType[j])
print("SVMTrain")
print(mean(SVMTrain))
print(range(SVMTrain))
print("SVMSummary")
print(mean(SVMSummary))
print(range(SVMSummary))
}

ModelOne=cbind(OatsData[,2],OatsData[,24],OatsData[,7],OatsData[,12],OatsData[,14],OatsData[,16],OatsData[,21],OatsData[,15],OatsData[,17],OatsData[,22],OatsData[,13],OatsData[,9],OatsData[,26:43],OatsData[,10],OatsData[,44:61])
ModelOne=ModelOne[-c(1,2,3),]

ModelOne=subset(ModelOne, !(ModelOne[,31] == 0))
ModelOne=cbind(ModelOne[,1:11],ModelOne[,13:30]/ModelOne[,12],ModelOne[,32:49]/ModelOne[,31],ModelOne[,13:30]/ModelOne[,12]-ModelOne[,32:49]/ModelOne[,31])
##ModelOne=cbind(ModelOne,ModelOne[,13:30]/ModelOne[,12]-ModelOne[,32:49]/ModelOne[,31])
dim(ModelOne)
selection=sequence(142)

for(j in 1:4){
for(i in 1:Interation){
	TrainSet=sample(selection,142,replace = FALSE)
	ModelOneMix=ModelOne[TrainSet,]

	TrainModel=ModelOneMix[1:93,]
	TrainModel[1,]=1
	TestModel=ModelOneMix[94:142,]
	TestModel[1,]=0
	
	x1 <- TrainModel[,3:65]##67
	y1 <- TrainModel[,2] ##Responce/outcome
	x2 <- TestModel[,3:65]##67
	y2 <- TestModel[,2] ##Responce/outcome
	model1 <- svm(x1, y1,type="C-classification",kernel=KernalType[j]) ##Train SVM
	pred1 <- predict(model1, x1)
	predtable1 = table(pred1, y1)
	pred2 <- predict(model1, x2)
	predtable2 = table(pred2, y2)
	SVMTrain[i]=(predtable1[1,1]+predtable1[2,2])/(sum(predtable1))
	SVMSummary[i]=(predtable2[1,1]+predtable2[2,2])/(sum(predtable2))	
}
print(KernalType[j])
print("SVMTrain")
print(mean(SVMTrain))
print(range(SVMTrain))
print("SVMSummary")
print(mean(SVMSummary))
print(range(SVMSummary))
}
