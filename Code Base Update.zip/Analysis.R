##Analysis,take 2##
FilePath <- "C:/Documents and Settings/jcs21/Desktop/WorkBackup041712"
setwd(FilePath)
#########################################################
NarrowReading <- read.csv("C:/Documents and Settings/jcs21/Desktop/WorkBackup041712/NarrowParameters/CompiledEditedReadings.csv")
length(NarrowReading[,11])
WideReading <- read.csv("C:/Documents and Settings/jcs21/Desktop/WorkBackup041712/ExpandedParameters/CompiledEditedReadings.csv")
length(WideReading[,11])
NarrowReading[1,]
range(NarrowReading$mzError)
range(NarrowReading$Sigma)
range(WideReading$mzError)
range(WideReading$Sigma)
#########################################################
NarrowReadingEdit = NarrowReading[NarrowReading[,11]>0,]
length(NarrowReadingEdit[,11])
WideReadingEdit = WideReading[WideReading[,11]>0,]
length(WideReadingEdit[,11])
range(NarrowReadingEdit$mzError)
range(NarrowReadingEdit$Sigma)
range(WideReadingEdit$mzError)
range(WideReadingEdit$Sigma)
#########################################################
pdf("GraphicalAnalysis.pdf")
par(mfrow=c(2,1))

plot(NarrowReadingEdit$Rsq,NarrowReadingEdit$Sigma)
plot(WideReadingEdit$Rsq,WideReadingEdit$Sigma)

plot(NarrowReadingEdit$Rsq,NarrowReadingEdit$mzError)
plot(WideReadingEdit$Rsq,WideReadingEdit$mzError)

plot(NarrowReadingEdit$Sigma,NarrowReadingEdit$Rsq)
plot(WideReadingEdit$Sigma,WideReadingEdit$Rsq)

plot(NarrowReadingEdit$mzError,NarrowReadingEdit$Rsq)
plot(WideReadingEdit$mzError,WideReadingEdit$Rsq)

library(scatterplot3d)
x=NarrowReadingEdit$mzError
y=NarrowReadingEdit$Sigma
z=NarrowReadingEdit$Rsq
scatterplot3d(x, y, z, xlab = "mzError", ylab = "Sigma", zlab = "Rsq")
plot(NarrowReadingEdit$Sigma,NarrowReadingEdit$mzError)

x=WideReadingEdit$mzError
y=WideReadingEdit$Sigma
z=WideReadingEdit$Rsq
scatterplot3d(x, y, z, xlab = "mzError", ylab = "Sigma", zlab = "Rsq")
plot(WideReadingEdit$Sigma,WideReadingEdit$mzError)
#########################################################
StNWide = WideReadingEdit$Area/WideReadingEdit$NoiseAdjust
plot(StNWide,WideReadingEdit$Rsq)
abline(v=c(3,10))
StNNarrow = NarrowReadingEdit$Area/NarrowReadingEdit$NoiseAdjust
plot(StNNarrow,NarrowReadingEdit$Rsq)
abline(v=c(3,10))
dev.off()

plot(StNWide,WideReadingEdit$Sigma)
barplot(table(WideReadingEdit$Area))
hist(WideReadingEdit$Area,breaks=seq(from=0,to=1000,by=10))

plot(WideReadingEdit$Mass,WideReadingEdit$mzError)
plot(NarrowReadingEdit$Mass,NarrowReadingEdit$mzError)