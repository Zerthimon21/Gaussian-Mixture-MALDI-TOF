SpectraImput <- xcmsRaw(FileList[1])
SpectraAverage <- getSpec(SpectraImput,mzrange=c(500,1350))
plot(SpectraAverage,type='l')
##########################################################
#Cluster = PeptideInformation[PeptideInformation$Cluster>=(1) & PeptideInformation$Cluster<=(1),]
#PeptideInformation[PeptideInformation$Cluster>=(1) & PeptideInformation$Cluster<=(1),]$Spectra=FileList[1]
#SpectraPeptideRange = SpectraAverage[SpectraAverage[,1]>=(min(Cluster$Mass)-1.008664916) & SpectraAverage[,1]<=(max(Cluster$Mass)+5*1.008664916),]
#plot(SpectraPeptideRange,type='l')
#PredictedData=rep(1,length(SpectraPeptideRange[,1]))

#for(l in 1:length(Cluster$Mass)){
#	PD=MultiNormCalc(SpectraPeptideRange[,1],Cluster$Sequence[l],Cluster$Mass[l],.1,.16)##mzError estimated from trial and error
#	PredictedData=cbind(PD[,2],PredictedData)
#}
##########################################################
SpectraImput <- xcmsRaw(FileList[1])
SpectraAverage <- getSpec(SpectraImput,mzrange=c(500,1350))
plot(SpectraAverage,type='l')

Cluster = PeptideInformation[PeptideInformation$Cluster==(3),]
#PeptideInformation[PeptideInformation$Cluster==(3),]$Spectra=FileList[1]
SpectraPeptideRange = SpectraAverage[SpectraAverage[,1]>=(min(Cluster$Mass)-1.008664916) & SpectraAverage[,1]<=(max(Cluster$Mass)+5*1.008664916),]
plot(SpectraPeptideRange,type='l')
PredictedData=rep(1,length(SpectraPeptideRange[,1]))

for(l in 1:length(Cluster$Mass)){
	PD=MultiNormCalc(SpectraPeptideRange[,1],Cluster$Sequence[l],Cluster$Mass[l],.14,.14)##mzError estimated from trial and error
	PredictedData=cbind(PD[,2],PredictedData)
}

soln=qr.solve(PredictedData,SpectraPeptideRange[,2])
#soln[-length(soln)]
yhat=PredictedData %*% soln
lines(SpectraPeptideRange[,1],yhat,col='red')

R=RsqCalc(SpectraPeptideRange,yhat)
R
			abline(v=Cluster$Mass, col='Blue')
			title(GraphTitle)##File/Peptide
			placer=.75*max(SpectraPeptideRange[,2])
			legend(x=max(Cluster$Mass)+3,y=placer,lty=c(1,1,1),legend=c('Spectra','Fit','+0 Peptide Isotope'),col=c('black','red','blue'))##Black/Red meaning

##########################################################
##########################################################
 SpectraEstimate <- EditedResults
 counter=0
 for(j in 1:length(SpectraEstimate$Mass)){
 if(j<=length(SpectraEstimate$Mass)-1){
 if ((SpectraEstimate$Mass[j]-SpectraEstimate$Mass[j+1])<5){
 SpectraEstimate$Cluster[j]=counter+1
 SpectraEstimate$Cluster[j+1]=counter+1
 }
 else{
 SpectraEstimate$Cluster[j]=counter+1
 SpectraEstimate$Cluster[j+1]=counter+2
 counter=counter+1}
 }
 else
 if ((SpectraEstimate$Mass[j-1]-SpectraEstimate$Mass[j])<5){
 SpectraEstimate$Cluster[j]=counter+1
 }
 else{
 SpectraEstimate$Cluster[j]=counter+1
 }
 }
SpectraEstimate

EditedResults
PeptideInformation
			#SpectraEstimate=PeptideInformation this works???????
			
			Cluster <- SpectraEstimate[SpectraEstimate$Cluster==(2),]
			Sigma <- Cluster$Sigma[1]
			print(Sigma)
			mzError <- Cluster$mzError[1]
			print(mzError)

			Cluster[,8:12]=NA

			SpectraPeptideRange <- SpectraAverage[SpectraAverage[,1]>=(min(Cluster$Mass)-1.008664916) & SpectraAverage[,1]<=(max(Cluster$Mass)+5*1.008664916),]
			plot(SpectraPeptideRange,type='l')##Plot Data - Black line

			PredictedData <- rep(1,length(SpectraPeptideRange[,1]))
			for(l in 1:length(Cluster$Mass)){
				PD=MultiNormCalc(SpectraPeptideRange[,1],Cluster$Sequence[l],Cluster$Mass[l],Sigma,mzError)  ##This may need editing??
				PredictedData=cbind(PD[,2],PredictedData)
			}

			##Soln=c(Cluster$Area,Cluster$NoiseAdjust[1])
			Soln=qr.solve(PredictedData,SpectraPeptideRange[,2])
			yhat=PredictedData %*% Soln

			lines(SpectraPeptideRange[,1],yhat,col='red')##Add Predictions - Red line
			GraphTitle <- paste(Cluster$Spectra[1],Cluster$Peptide[1])
			abline(v=Cluster$Mass, col='Blue')
			title(GraphTitle)##File/Peptide
			placer=.75*max(SpectraPeptideRange[,2])
			legend(x=max(Cluster$Mass)+3,y=placer,lty=c(1,1,1),legend=c('Spectra','Fit','+0 Peptide Isotope'),col=c('black','red','blue'))##Black/Red meaning
}}

##########################################################
##########################################################
par(mfrow = c(3,2))
plot(SpectraPeptideRange,type='l')
plot(SpectraPeptideRange[,1],PredictedData[,1],type='l')
plot(SpectraPeptideRange[,1],PredictedData[,2],type='l')
plot(SpectraPeptideRange[,1],PredictedData[,3],type='l')
plot(SpectraPeptideRange[,1],PredictedData[,4],type='l')

fit=SpectraPeptideRange[,2]/max(SpectraPeptideRange[,2])
plot(SpectraPeptideRange[,1],fit,type='l',ylim=c(-.5,1))
lines(SpectraPeptideRange[,1],PredictedData[,3],col='red')
lines(SpectraPeptideRange[,1],PredictedData[,4],col='blue')
##########################################################
##Need to sdit out all entries with lover rsq than what i want
QuickEditResults <- function(Record,cutoff){
	write.csv(Record,'FullReadingOfFiles.csv')
	#OutPut <- Record[order(-Record$Rsq),]##Order by decreasing Rsq Value
	OutPut <- Record[Record$Rsq>=(cutoff),]
	write.csv(OutPut,'FullReadingFilteredByRsq.csv')
	#OutPut <- OutPut[,!duplicated(OutPut$Rsq)]  ##This filters out copied clusters, but depends on each cluster in set having different rsq values will need tobe monitored 
	#write.csv(OutPut,'FullReadingFiltered2.csv')
	OutPut
}
##########################################################
##Graph all selected, filtered values 
ViewFitResults <- function(Record,FileList){
	pdf(file = "Test Brute Force FFT fitting plots.pdf")	##need to remane output pdf with funtion input for easier file handling
	par(mfrow = c(3,1))
	OutPut <- Record
	for(i in 1:max(OutPut$SpectraCount)){
		SpectraImput <- xcmsRaw(FileList[i])
		SpectraAverage <- getSpec(SpectraImput,mzrange=c(500,1350))
		SpectraEstimate <- OutPut[OutPut$SpectraCount==(i)]

		##rewrite the cluster number to make printing easier		
		counter=0
		for(j in 1:length(SpectraEstimate$Mass)){
			if(j<=length(SpectraEstimate$Mass)-1){
				if ((SpectraEstimate$Mass[j]-SpectraEstimate$Mass[j+1])<5){
					SpectraEstimate$Cluster[j]=counter+1
					SpectraEstimate$Cluster[j+1]=counter+1
				}
				else{
					SpectraEstimate$Cluster[j]=counter+1
					SpectraEstimate$Cluster[j+1]=counter+2
					counter=counter+1}
				}
			else
				if ((SpectraEstimate$Mass[j-1]-PeptideInformation$Mass[j])<5){
					SpectraEstimate$Cluster[j]=counter+1
				}
				else{
					SpectraEstimate$Cluster[j]=counter+1
				}
		}

		##Now print every entry by cluster
		for(k in 1:max(SpectraEstimate$Cluster)){
				Cluster <- SpectraEstimate[SpectraEstimate$Cluster==(k),]
				SpectraPeptideRange <- SpectraAverage[SpectraAverage[,1]>=(min(Cluster$Mass)-1.008664916) & SpectraAverage[,1]<=(max(Cluster$Mass)+5*1.008664916),]
				PredictedData <- rep(1,length(SpectraPeptideRange[,1]))
				for(l in 1:length(Cluster$Mass)){
					PD <- MultiNormCalc(SpectraPeptideRange[,1],Cluster$Sequence[l],Cluster$Mass[l],Cluster$Sigma[l],Cluster$mzError[l])  ##This may need editing??
					PredictedData=cbind(PD[,2],PredictedData)
				}
				Soln=qr.solve(PredictedData,SpectraPeptideRange[,2])
				yhat=PredictedData %*% Soln
				plot(SpectraPeptideRange,type='l')##Plot Data - Black line
				lines(SpectraPeptideRange[,1],yhat,type='l',col='red')##Add Predictions - Red line
				GraphTitle <- paste(Cluster$Spectra[1],Cluster$Peptide[1])
				abline(v=Cluster$Mass, col='Blue')
				title(GraphTitle)##File/Peptide
				placer=.75*max(SpectraPeptideRange[,2])
				legend(x=max(Cluster$Mass)+5,y=placer,lty=c(1,1,1),legend=c('Spectra','Fit','+0 Peptide Isotope'),col=c('black','red','blue'))##Black/Red meaning
}}
	dev.off()
	cat("Please remember to shutdown R before opening any large .PDF, thank you.","\n")
}
#######################################
#######################################
#######################################


for(i in 1:max(Record$SpectraCount)){
	SpectraEstimate = Record[Record$SpectraCount==(1)]
	counter=0
		for(j in 1:length(SpectraEstimate$Mass)){
			if(j<=length(SpectraEstimate$Mass)-1){
				if ((SpectraEstimate$Mass[j]-SpectraEstimate$Mass[j+1])<5){
					SpectraEstimate$Cluster[j]=counter+1
					SpectraEstimate$Cluster[j+1]=counter+1
				}
				else{
					SpectraEstimate$Cluster[j]=counter+1
					SpectraEstimate$Cluster[j+1]=counter+2
					counter=counter+1}
				}
			else
				if ((SpectraEstimate$Mass[j-1]-SpectraEstimate$Mass[j])<5){
					SpectraEstimate$Cluster[j]=counter+1
				}
				else{
					SpectraEstimate$Cluster[j]=counter+1
				}
		}
	Record[Record$SpectraCount==(i)] = SpectraEstimate
}
	pdf(file = "Test Brute Force FFT fitting plots.pdf")	##need to remane output pdf with funtion input for easier file handling
	par(mfrow = c(3,1))
	OutPut <- SpectraEstimate
		SpectraImput <- xcmsRaw(FileList[1])
		SpectraAverage <- getSpec(SpectraImput,mzrange=c(500,1350))

		##Now print every entry by cluster
		for(k in 1:max(SpectraEstimate$Cluster)){
			Cluster <- SpectraEstimate[SpectraEstimate$Cluster==(k),]
			SpectraPeptideRange <- SpectraAverage[SpectraAverage[,1]>=(min(Cluster$Mass)-1.008664916) & SpectraAverage[,1]<=(max(Cluster$Mass)+5*1.008664916),]
			plot(SpectraPeptideRange,type='l')##Plot Data - Black line

			Sigma <- Cluster$Sigma[1]
			print(Sigma)
			mzError <- Cluster$mzError[1]
			print(mzError)

			PredictedData <- rep(1,length(SpectraPeptideRange[,1]))
			for(l in 1:length(Cluster$Mass)){
				PD <- MultiNormCalc(SpectraPeptideRange[,1],Cluster$Sequence[l],Cluster$Mass[l],Sigma,mzError)  ##This may need editing??
				PredictedData=cbind(PD[,2],PredictedData)
			}

			Soln=qr.solve(PredictedData,SpectraPeptideRange[,2])
			yhat=PredictedData %*% Soln

			lines(SpectraPeptideRange[,1],yhat,col='red')##Add Predictions - Red line
			GraphTitle <- paste(Cluster$Spectra[1],Cluster$Peptide[1])
			abline(v=Cluster$Mass, col='Blue')
			title(GraphTitle)##File/Peptide
			placer=.75*max(SpectraPeptideRange[,2])
			legend(x=max(Cluster$Mass)+3,y=placer,lty=c(1,1,1),legend=c('Spectra','Fit','+0 Peptide Isotope'),col=c('black','red','blue'))##Black/Red meaning
}
	dev.off()
	cat("Please remember to shutdown R before opening any large .PDF, thank you.","\n")

